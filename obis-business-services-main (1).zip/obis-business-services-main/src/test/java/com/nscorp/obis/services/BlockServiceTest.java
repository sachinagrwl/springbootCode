package com.nscorp.obis.services;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nscorp.obis.exception.NoRecordsFoundException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.nscorp.obis.domain.Block;
import com.nscorp.obis.dto.BlockDTO;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.repository.BlockRepository;

public class BlockServiceTest {

	@Mock
	BlockRepository blockRepository;

	@InjectMocks
	BlockServiceImpl blockService;
	
	Block block;
	Block blockResource;
	Block blockUpdated;
	
	BlockDTO blockDto;
	List<BlockDTO> blockDtoList;
	List<BlockDTO> blockDTOList;
	ResponseEntity<Object> responseEntity;
	String url;
	List<Block> blockList;
	Map<String, String> header;
	String type, trainNr;
	double termId;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		block = new Block();
		blockList = new ArrayList<>();
		blockDto = new BlockDTO();
		blockDtoList = new ArrayList<>();
		block.setTermId(6.0);
		block.setTrainNr("20E");
		block.setBlockId(1.1441658100764E13);
		block.setBlockNm("This should not be null");
		block.setParantBlockId(null);
		block.setBlockOrder("4");
		block.setBlockPriority(2);
		block.setSwInterchange("Y");
		block.setAllowSameCar("Y");
		block.setBlockMon("Y");
		block.setBlockTue("Y");
		block.setBlockWed("Y");
		block.setBlockThu("Y");
		block.setBlockFri("Y");
		block.setBlockSat("Y");
		block.setBlockSun("Y");
		block.setHightFeet(20);
		block.setHightInches(3);
		block.setWeight(125);

		blockDto.setTermId(6.0);
		blockDto.setTrainNr("20E");
		blockDto.setBlockId(1.1441658100764E13);
		blockDto.setBlockNm("This should not be 0");
		blockDto.setParantBlockId(null);
		blockDto.setBlockOrder("34");
		blockDto.setBlockPriority(3);
		blockDto.setSwInterchange("Y");
		blockDto.setAllowSameCar("Y");
		blockDto.setBlockMon("Y");
		blockDto.setBlockTue("Y");
		blockDto.setBlockWed("Y");
		blockDto.setBlockThu("Y");
		blockDto.setBlockFri("Y");
		blockDto.setBlockSat("Y");
		blockDto.setBlockSun("Y");
		blockDto.setHightFeet(20);
		blockDto.setHightInches(3);
		blockDto.setWeight(125);
		blockList.add(block);
		// blockDtoList.add(blockDto);

		termId = 6.0;
		trainNr = "20E";
		header = new HashMap<String, String>();
		header.put("userid", "Test");
		header.put("extensionschema", "Test");

	}

	@AfterEach
	void tearDown() throws Exception {

		blockDto = null;
		blockDtoList = null;
		block = null;
		blockList = null;
	}

	@Test
	void testGetBlocks() {
		when(blockRepository.findByTermIdAndTrainNr(Mockito.anyDouble(), Mockito.anyString())).thenReturn(blockList);
		List<Block> getBlock = blockService.getAllBlocks(termId, trainNr);
		assertEquals(getBlock, blockList);

	}
		
	@Test
	void testGetBlockException() {

		NoRecordsFoundException exception = assertThrows(NoRecordsFoundException.class,
				() -> when(blockService.getAllBlocks(termId, trainNr)));
		assertEquals("No records found", exception.getMessage());
		
	}	
	
	@Test
	void testUpdateBlockNoRecordsFoundException() {
		NoRecordsFoundException exception = assertThrows(NoRecordsFoundException.class,
				() -> blockService.updateBlock(block, header));
		assertEquals("Record with BlockID " + block.getBlockId() + " Not Found!", exception.getMessage());

	}

	
	@Test
	void testUpdateBlock() {

		when(blockRepository.existsByBlockId(Mockito.any())).thenReturn(true);
		when(blockRepository.findByBlockId(Mockito.any())).thenReturn(block);
		when(blockRepository.save(Mockito.any())).thenReturn(block);
		blockUpdated = blockService.updateBlock(block, header);
		assertEquals(blockUpdated.getBlockId(), block.getBlockId());
	}
	 
	 


}