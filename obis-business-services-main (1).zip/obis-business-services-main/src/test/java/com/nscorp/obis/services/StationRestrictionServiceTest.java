package com.nscorp.obis.services;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.nscorp.obis.domain.StationRestriction;
import com.nscorp.obis.dto.StationRestrictionDTO;
import com.nscorp.obis.repository.StationRestrictionRepository;

class StationRestrictionServiceTest {
	
	@InjectMocks
	StationRestrictionServiceImpl stationRestrictionService;

	@Mock
	//@Autowired
	StationRestrictionRepository stationRestrictionRepository;
	
	StationRestriction  stationRestriction;
	StationRestriction  stationRestrictionResource;
	StationRestrictionDTO  stationRestrictionDto;
	List<StationRestriction> stationRestrictionList;
	StationRestriction addedTermId;
	
	
	Map<String, String> header;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
		System.out.println("Repo:- "+ stationRestrictionRepository);
		
		stationRestriction = new StationRestriction();
		stationRestriction.setStationCrossReferenceId(100000000);
		stationRestriction.setCarType("S159");
		stationRestriction.setFreightType("____");
		
		stationRestrictionList = new ArrayList<>();

		stationRestrictionDto = new StationRestrictionDTO();
		stationRestrictionDto.setStationCrossReferenceId(100000000);
		stationRestrictionDto.setCarType("S159");
		stationRestrictionDto.setFreightType("___");
		
		stationRestrictionResource = new StationRestriction();
		stationRestrictionResource.setStationCrossReferenceId(100000000);
		stationRestrictionResource.setCarType("S159");
		stationRestrictionResource.setFreightType("____");
		
		header = new HashMap<String, String>();
		header.put("userid", "Test");
		header.put("extensionschema", "Test");
		
	}

	@AfterEach
	void tearDown() throws Exception {
	}
	
	@Test
	void testGetAllStationRestrictions() {
		try {
		when(stationRestrictionRepository.findByStationCrossReferenceId((long) 100000000)).thenReturn(stationRestrictionList);
		List<StationRestriction> allTermId = stationRestrictionService.getStationRestriction((long) 100000000);
		assertEquals(allTermId, stationRestrictionList);
		}catch(Exception e) {
			e.getMessage();
		}
	}

	@Test
	void testAddStationRestriction() {
		try {
			when(stationRestrictionRepository.save(any(StationRestriction.class))).thenReturn(stationRestrictionResource);
			addedTermId = stationRestrictionService.addStationRestriction((long) 100000000, stationRestriction, Mockito.any(), Mockito.any());
			assertEquals(addedTermId.getStationCrossReferenceId(), stationRestriction.getStationCrossReferenceId());
			assertEquals(addedTermId.getCarType(), stationRestriction.getCarType());
			assertEquals(addedTermId.getFreightType(), stationRestriction.getFreightType());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}		
	}

	@Test
	void testDeleteStationRestriction() {
		try {
			when(stationRestrictionRepository.save(stationRestriction)).thenReturn(null);
			stationRestrictionService.deleteStationRestriction((long) 100000000, stationRestriction);
		} catch (Exception e) {
			e.getMessage();
		}
	}

}
