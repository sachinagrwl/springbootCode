package com.nscorp.obis.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.nscorp.obis.domain.TerminalTrain;
import com.nscorp.obis.dto.EquipmentDefaultTareWeightMaintenanceDTO;
import com.nscorp.obis.dto.TerminalTrainDTO;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.exception.RecordNotDeletedException;
import com.nscorp.obis.repository.BlockRepository;
import com.nscorp.obis.repository.TerminalTrainRepository;

public class TerminalTrainServiceTest {
	
	@InjectMocks
	TerminalTrainServiceImpl terminalTrainService;

	@Mock
	TerminalTrainRepository terminalTrainRepository;
	
	@Mock
	BlockRepository blockRepository;
	
	
	
	TerminalTrainDTO terminalTrainDto;
	TerminalTrain terminalTrain;
	List<TerminalTrain> terminalTrainList;
	List<TerminalTrainDTO> terminalTrainDtoList;

	Map<String, String> header;
	
	
	
	TerminalTrain deleteTrain;
	TerminalTrain UpdatedTrainDesc;
	


	@BeforeEach
	void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
		
		terminalTrain= new TerminalTrain();
		terminalTrainDto = new TerminalTrainDTO();
		terminalTrainDtoList = new ArrayList<>();
		terminalTrainList = new ArrayList<>();

		terminalTrain.setTermId((long) 12345);
		terminalTrain.setTrainNr("123");
		terminalTrain.setTrainDesc("Description of a specific train");
		terminalTrain.setCutoffDefault(null);
		terminalTrain.setCutoffMon(null);
		terminalTrain.setCutoffTue(null);
		terminalTrain.setCutoffWed(null);
		terminalTrain.setCutoffThu(null);
		terminalTrain.setCutoffFri(null);
		terminalTrain.setCutoffSat(null);
		terminalTrain.setCutoffSun(null);
		terminalTrain.setTrainDir("Train Directory");
		terminalTrain.setMaxFootage(564738);
	
		
		terminalTrainDto = new TerminalTrainDTO();
		terminalTrainDto.setTermId((long) 12345);
		terminalTrainDto.setTrainNr("123");
		terminalTrainDto.setTrainDesc("Description of a specific train");
		terminalTrainDto.setCutoffDefault(null);
		terminalTrainDto.setCutoffMon(null);
		terminalTrainDto.setCutoffTue(null);
		terminalTrainDto.setCutoffWed(null);
		terminalTrainDto.setCutoffThu(null);
		terminalTrainDto.setCutoffFri(null);
		terminalTrainDto.setCutoffSat(null);
		terminalTrainDto.setCutoffSun(null);
		terminalTrainDto.setTrainDir("Train Directory");
		terminalTrainDto.setMaxFootage(564738);
		terminalTrainDtoList.add(terminalTrainDto);
		terminalTrainList.add(terminalTrain);

			
		header = new HashMap<String, String>();
		header.put("userid", "Test");
		header.put("extensionschema", "Test");
	}
	
	@AfterEach
	void tearDown() throws Exception {
		terminalTrainList = null;
		terminalTrainDtoList = null;
		terminalTrainDto = null;
		terminalTrain = null;
	}
	

	    @Test
	    void testGetAllTerminalTrains() {
	        when(terminalTrainRepository.findAll()).thenReturn(terminalTrainList);
	        List<TerminalTrain> allTerminalTrains= terminalTrainService.getAllTerminalTrains();
	        assertEquals(allTerminalTrains,terminalTrainList);    
	    }
	    
	    @Test
		void testGetAllTerminalTrainsException() {
	    	NoRecordsFoundException exception = assertThrows(NoRecordsFoundException.class,
					() -> when(terminalTrainService.getAllTerminalTrains()));
	    	assertEquals("No records found", exception.getMessage());
	    }
	   
	   
	   
	   @Test
		void testUpdateTrainDesc() {
		   when(terminalTrainRepository.existsByTermIdAndTrainNr(Mockito.any(),Mockito.any())).thenReturn(true);
			when(terminalTrainRepository.findByTermIdAndTrainNr(Mockito.any(),Mockito.any())).thenReturn(terminalTrain);
			when(terminalTrainRepository.save(Mockito.any())).thenReturn(terminalTrain);
				UpdatedTrainDesc = terminalTrainService.updateTrainDesc(terminalTrain, header);
				UpdatedTrainDesc.setTermId((long) 12345);
//				assertNotNull(loadUpdated.getTermId());
				assertEquals(UpdatedTrainDesc, terminalTrain);			
		}
	   
	   @Test
		void testUpdateTrainDescNoRecordsFoundException() {
			NoRecordsFoundException exception = assertThrows(NoRecordsFoundException.class,
					() -> terminalTrainService.updateTrainDesc(terminalTrain, header));
			assertEquals("No record Found Under this Term Id:"+terminalTrain.getTermId()+" and Train Nr:"+terminalTrain.getTrainNr(), exception.getMessage());

	   }	
	   @Test
		void testDeleteTrain() {
			when(terminalTrainRepository.existsByTermIdAndTrainNr(Mockito.any(),Mockito.any())).thenReturn(true);
			when(terminalTrainRepository.findByTermIdAndTrainNr(Mockito.any(),Mockito.any())).thenReturn(terminalTrain);
			//when(blockRepository.existsByTermIdAndTrainNr(Mockito.any(),Mockito.any())).thenReturn(terminalTrain);
			terminalTrainService.deleteTrain(terminalTrain);
		}
	   
	   @Test
		void testDeleteTrainRecordNotDeletedException() {
			RecordNotDeletedException exception = assertThrows(RecordNotDeletedException.class,
					() -> terminalTrainService.deleteTrain(terminalTrain));
			assertEquals(terminalTrain.getTermId()  + " and " + terminalTrain.getTrainNr() + " Record Not Found!",exception.getMessage());

	   }
}
