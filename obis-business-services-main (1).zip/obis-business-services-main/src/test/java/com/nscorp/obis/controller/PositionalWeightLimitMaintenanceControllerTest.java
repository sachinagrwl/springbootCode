package com.nscorp.obis.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.nscorp.obis.domain.PositionalWeightLimitMaintenance;
import com.nscorp.obis.dto.PositionalWeightLimitMaintenanceDTO;
import com.nscorp.obis.dto.mapper.PositionalWeightLimitMaintenanceMapper;
import com.nscorp.obis.response.APIResponse;
import com.nscorp.obis.services.PositionalWeightLimitMaintenanceService;

class PositionalWeightLimitMaintenanceControllerTest {

	@Mock
	PositionalWeightLimitMaintenanceService positionalWeightLimitMaintenanceService;

	@Mock
	PositionalWeightLimitMaintenanceMapper positionalWeightLimitMaintenanceMapper;

	@InjectMocks
	PositionalWeightLimitMaintenanceController positionalWeightLimitMaintenanceController;

	PositionalWeightLimitMaintenanceDTO positionalWeightLimitMaintenanceDto;
	PositionalWeightLimitMaintenance positionalWeightLimitMaintenance;
	List<PositionalWeightLimitMaintenance> positionalWeightLimitMaintenanceList;
	List<PositionalWeightLimitMaintenanceDTO> positionalWeightLimitMaintenanceDtoList;

	Map<String, String> header;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
		positionalWeightLimitMaintenance = new PositionalWeightLimitMaintenance();
		positionalWeightLimitMaintenance.setCarInit("TEST");
		positionalWeightLimitMaintenance.setCarNrLow((long) 12345);
		positionalWeightLimitMaintenance.setCarNrHigh((long) 45678);
		positionalWeightLimitMaintenance.setCarEquipmentType("F");
		positionalWeightLimitMaintenance.setAarType("R476");
		positionalWeightLimitMaintenance.setCarOwner("TTX");
		positionalWeightLimitMaintenance.setC20MaxWeight(564738);
		positionalWeightLimitMaintenance.setCarDescription("6 articulated 100 ton well car");
		
		positionalWeightLimitMaintenanceList = new ArrayList<>();
		positionalWeightLimitMaintenanceList.add(positionalWeightLimitMaintenance);
		
		positionalWeightLimitMaintenanceDto = new PositionalWeightLimitMaintenanceDTO();
		positionalWeightLimitMaintenanceDto.setCarInit("TEST");
		positionalWeightLimitMaintenanceDto.setCarNrLow((long) 12345);
		positionalWeightLimitMaintenanceDto.setCarNrHigh((long) 45678);
		positionalWeightLimitMaintenanceDto.setCarEquipmentType("F");
		positionalWeightLimitMaintenanceDto.setAarType("R476");
		positionalWeightLimitMaintenanceDto.setCarOwner("TTX");
		positionalWeightLimitMaintenanceDto.setC20MaxWeight(564738);
		positionalWeightLimitMaintenanceDto.setCarDescription("6 articulated 100 ton well car");
		
		positionalWeightLimitMaintenanceDtoList = new ArrayList<>();
		//positionalWeightLimitMaintenanceDtoList = new List<PositionalWeightLimitMaintenanceDTO>();
		positionalWeightLimitMaintenanceDtoList.add(positionalWeightLimitMaintenanceDto);
		
		header = new HashMap<String, String>();
		header.put("userid", "Test");
		header.put("extensionschema", "Test");
	}


	@AfterEach
	void tearDown() throws Exception {
		
		positionalWeightLimitMaintenanceDto = null;
		positionalWeightLimitMaintenance = null;
		positionalWeightLimitMaintenanceList = null;
		positionalWeightLimitMaintenanceDtoList = null;
		
	}

	@Test
	void testGetAllPositionalLoadLimits() {
		when(positionalWeightLimitMaintenanceService.getAllLoadLimits()).thenReturn(positionalWeightLimitMaintenanceList);
		ResponseEntity<APIResponse<List<PositionalWeightLimitMaintenanceDTO>>> positionalWeightLimitMaintenanceList = positionalWeightLimitMaintenanceController.getAllPositionalLoadLimits();
		assertNotNull(positionalWeightLimitMaintenanceList.getBody());
	}

	@Test
	void testAddLoadLimits() {
		when(positionalWeightLimitMaintenanceMapper.positionalWeightLimitMaintenanceDTOToPositionalWeightLimitMaintenance(Mockito.any())).thenReturn(positionalWeightLimitMaintenance);
		when(positionalWeightLimitMaintenanceService.insertLoad(Mockito.any(), Mockito.any())).thenReturn(positionalWeightLimitMaintenance);
		when(positionalWeightLimitMaintenanceMapper.positionalWeightLimitMaintenanceToPositionalWeightLimitMaintenanceDTO(Mockito.any())).thenReturn(positionalWeightLimitMaintenanceDto);
		ResponseEntity<APIResponse<PositionalWeightLimitMaintenanceDTO>> addedLoad = positionalWeightLimitMaintenanceController.addLoadLimits(positionalWeightLimitMaintenanceDto,
				header);
		assertNotNull(addedLoad.getBody());
	}

	@Test
	void testUpdatePositionalWeightLimitMaintenance() {
		when(positionalWeightLimitMaintenanceMapper.positionalWeightLimitMaintenanceDTOToPositionalWeightLimitMaintenance(Mockito.any())).thenReturn(positionalWeightLimitMaintenance);
		when(positionalWeightLimitMaintenanceService.updatePositionalWeightLimitMaintenance(Mockito.any(), Mockito.any())).thenReturn(positionalWeightLimitMaintenance);
		when(positionalWeightLimitMaintenanceMapper.positionalWeightLimitMaintenanceToPositionalWeightLimitMaintenanceDTO(Mockito.any())).thenReturn(positionalWeightLimitMaintenanceDto);
		ResponseEntity<APIResponse<PositionalWeightLimitMaintenanceDTO>> loadUpdated = positionalWeightLimitMaintenanceController.updatePositionalWeightLimitMaintenance(positionalWeightLimitMaintenanceDto, header);
		assertNotNull(loadUpdated.getBody());
	}

	@Test
	void testDeletePositionalWeightLimitMaintenance() {
//		doNothing().when(positionalWeightLimitMaintenanceService).deletePositionalWeightLimitMaintenance(positionalWeightLimitMaintenanceList);
//		positionalWeightLimitMaintenanceController.deletePositionalWeightLimitMaintenance(positionalWeightLimitMaintenanceList);
		
		positionalWeightLimitMaintenanceController.deletePositionalWeightLimitMaintenance(positionalWeightLimitMaintenanceDtoList);	
		//when(positionalWeightLimitMaintenanceController.deletePositionalWeightLimitMaintenance(positionalWeightLimitMaintenanceList)).thenThrow(RuntimeException.class);
	}

}
