package com.nscorp.obis.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;

import com.nscorp.obis.domain.Block;
import com.nscorp.obis.dto.BlockDTO;
import com.nscorp.obis.dto.mapper.BlockMapper;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.exception.SizeExceedException;
import com.nscorp.obis.response.APIResponse;
import com.nscorp.obis.services.BlockService;

//@SpringBootTest
public class BlockControllerTest {
	@Mock
	BlockService blockService;
	
	@Mock
	BlockMapper blockMapper;
	
	@InjectMocks
	BlockController blockController;

		Block block;
		BlockDTO blockDto;
		List<BlockDTO> blockDtoList;
		List<BlockDTO> blockDTOList;
		ResponseEntity<Object> responseEntity;

		List<Block> blockList;
		Map<String, String> header;
		String trainNr;
		double termId;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		block = new Block();
		blockDto = new BlockDTO();
		blockDtoList = new ArrayList<>();
		blockList = new ArrayList<>();
		// block.setTrainNr("INT FLAT");
		block.setBlockId(1.14536627525278);
		block.setBlockNm("The world limit ");
		block.setBlockOrder("13");
		block.setBlockPriority(6);
		block.setAllowSameCar("N");
		block.setBlockMon("Y");
		block.setBlockTue("Y");
		block.setBlockWed("Y");
		block.setBlockThu("Y");
		block.setBlockFri("Y");
		block.setBlockSat("Y");
		block.setBlockSun("Y");
		block.setHightFeet(20);
		block.setHightInches(3);

		blockDto.setBlockId(1.14536627525278);
		blockDto.setBlockNm("The world limit ");
		blockDto.setBlockOrder("13");
		blockDto.setBlockPriority(6);
		blockDto.setAllowSameCar("N");
		blockDto.setBlockMon("Y");
		blockDto.setBlockTue("Y");
		blockDto.setBlockWed("Y");
		blockDto.setBlockThu("Y");
		blockDto.setBlockFri("Y");
		blockDto.setBlockSat("Y");
		blockDto.setBlockSun("Y");
		blockDto.setHightFeet(20);
		blockDto.setHightInches(3);

		blockList = new ArrayList<>();
		termId = 35.4223;
		trainNr = "XYZ";
		header = new HashMap<String, String>();
		header.put("userid", "Test");
		header.put("extensionschema", "Test");

	}

	@AfterEach
	void tearDown() throws Exception {


		blockDto = null;
		blockDtoList = null;
		blockDto = null;
		blockList = null;
	}		

		@Test
		void testGetBlock() {
			
				when(blockService.getAllBlocks(Mockito.any(), Mockito.any())).thenReturn(blockList);
				ResponseEntity<APIResponse<List<BlockDTO>>> blockList = blockController.getBlocksByTermIdAndTrainNr(termId, trainNr);
				assertEquals(blockList.getStatusCodeValue(), 200);
			}

		@Test
		void testNullListGet(){
			blockList = Collections.emptyList();
			when(blockService.getAllBlocks(termId, trainNr)).thenReturn(blockList);
			assertEquals(Collections.EMPTY_LIST,blockList);	
			

		}	

		@Test
		void testBlockNoRecordsFoundException() {
			when(blockService.getAllBlocks(termId, trainNr)).thenThrow(new NoRecordsFoundException());
	        when(blockService.updateBlock(Mockito.any(),Mockito.any())).thenThrow(new NoRecordsFoundException());

	        ResponseEntity<APIResponse<List<BlockDTO>>> blockList = blockController.getBlocksByTermIdAndTrainNr(termId, trainNr);
	        ResponseEntity<APIResponse<BlockDTO>> blockUpdate =  blockController.updateBlock(Mockito.any(),Mockito.any());

	        assertEquals(blockList.getStatusCodeValue(), 404);
	        assertEquals(blockUpdate.getStatusCodeValue(),404);
	    }	
		
		@Test
	    void testBlockSizeExceedException() 
		{
	        when(blockService.updateBlock(Mockito.any(),Mockito.any())).thenThrow(new SizeExceedException("Size Exceed"));

	        ResponseEntity<APIResponse<BlockDTO>> blockUpdate =  blockController.updateBlock(Mockito.any(),Mockito.any());

	        assertEquals(blockUpdate.getStatusCodeValue(),411);
	    }
		
		
		@Test
	    void testBlockNullPointerException() {
	        when(blockService.updateBlock(Mockito.any(),Mockito.any())).thenThrow(new NullPointerException("Null pointer"));

	        ResponseEntity<APIResponse<BlockDTO>> blockUpdate =  blockController.updateBlock(Mockito.any(),Mockito.any());

	        assertEquals(blockUpdate.getStatusCodeValue(),400);
	    }
		
		@Test
		void testBlockException() {
			when(blockService.getAllBlocks(termId, trainNr)).thenThrow(new RuntimeException());
	        when(blockService.updateBlock(Mockito.any(),Mockito.any())).thenThrow(new RuntimeException());

			ResponseEntity<APIResponse<List<BlockDTO>>> blockList = blockController.getBlocksByTermIdAndTrainNr(termId, trainNr);
	        ResponseEntity<APIResponse<BlockDTO>> blockUpdate = blockController.updateBlock(Mockito.any(),Mockito.any());

	        assertEquals(blockList.getStatusCodeValue(), 500);
	        assertEquals(blockUpdate.getStatusCodeValue(), 500);
	    }

		
		@Test
		void testUpdate() {
			when(blockMapper.blockDTOToBlock(Mockito.any())).thenReturn(block);
			when(blockService.updateBlock(Mockito.any(), Mockito.any())).thenReturn(block);
			when(blockMapper.blockToBlockDTO(Mockito.any())).thenReturn(blockDto);
			ResponseEntity<APIResponse<BlockDTO>> codeUpdated = blockController.updateBlock(blockDto, header);
			// assertEquals(codeUpdated.getBody().getData(),blockDto);
			assertNotNull(codeUpdated.getBody().getData());
		}
		
		 
	}

	


