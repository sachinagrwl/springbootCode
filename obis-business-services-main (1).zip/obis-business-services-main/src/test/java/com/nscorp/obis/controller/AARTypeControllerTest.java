package com.nscorp.obis.controller;

import com.nscorp.obis.domain.AARType;
import com.nscorp.obis.dto.AARTypeDTO;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.response.APIResponse;
import com.nscorp.obis.services.AARTypeService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class AARTypeControllerTest {

	@Mock
	AARTypeService aarTypeService;

	@InjectMocks
	AARTypeController aarTypeController;

	AARTypeDTO aarTypeDto;
	AARType aarType;
	List<AARType> aarTypeList;
	List<AARTypeDTO> aarTypeDTOList;
	
	Map<String, String> header;
	String type;
	String type2;
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		aarType = new AARType();
		aarType.setAarCapacity(1);
		aarType.setAarType("P110");
		aarType.setAarDescription("DEMO");
		aarType.setImDescription("Demo");
		aarType.setStandardAarType("Demo");
		aarTypeList = new ArrayList<>();

		aarTypeList.add(aarType);
		aarTypeDto = new AARTypeDTO();
		aarTypeDto.setAarCapacity(1);
		aarTypeDto.setAarType("P110");
		aarTypeDto.setAarDescription("DEMO");
		aarTypeDto.setImDescription("Demo");
		aarTypeDto.setStandardAarType("Demo");
		aarTypeDTOList = new ArrayList<>();
		aarTypeDTOList.add(aarTypeDto);
		type = "car";
		type2 = "freight";
	}

	@AfterEach
	void tearDown() throws Exception {
		aarType = null;
		aarTypeDto = null;
		aarTypeDTOList = null;
		aarTypeList = null;
	}

	@Test
	void testGetAllAARTypes() {
		when(aarTypeService.getAllAARTypes(type)).thenReturn(aarTypeList);
		ResponseEntity<APIResponse<List<AARTypeDTO>>> aarTypeList = aarTypeController.getAllAARTypes(type);
		assertEquals(aarTypeList.getStatusCodeValue(),200);
	}

	@Test
	void testGetAllAARTypesNoRecordsFoundException() {
		when(aarTypeService.getAllAARTypes(Mockito.any())).thenThrow(new NoRecordsFoundException());
		ResponseEntity<APIResponse<List<AARTypeDTO>>> corporateCustomerListGet = aarTypeController.getAllAARTypes(Mockito.any());
		assertEquals(corporateCustomerListGet.getStatusCodeValue(),404);
	}

	@Test
	void testGetAllAARTypesException() {
		when(aarTypeService.getAllAARTypes(Mockito.any())).thenThrow(new RuntimeException());
		ResponseEntity<APIResponse<List<AARTypeDTO>>> corporateCustomerListGet = aarTypeController.getAllAARTypes(Mockito.any());
		assertEquals(corporateCustomerListGet.getStatusCodeValue(),500);
	}

}
