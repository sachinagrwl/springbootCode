package com.nscorp.obis.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.nscorp.obis.domain.NotifyProfileMethod;
import com.nscorp.obis.dto.NotifyProfileMethodDTO;
import com.nscorp.obis.repository.NotifyProfileMethodRepository;

public class NotifyProfileMethodServiceTest {
	
	@InjectMocks
	NotifyProfileMethodServiceImpl notifyProfileMethodService;
	
	@Mock
	NotifyProfileMethodRepository notifyProfileMethodRepository;
	
	NotifyProfileMethod notifyProfileMethod;
	NotifyProfileMethodDTO notifyProfileMethodDTO;
	List<NotifyProfileMethod> notifyProfileMethodList;
	List<NotifyProfileMethodDTO> notifyProfileMethodDTOs;
	
	NotifyProfileMethod updatedNotifyProfileMethod;
	
	String notificationName;
	Long notifyMethodId;
	Map<String, String> header;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
		notifyProfileMethod = new NotifyProfileMethod();
		notifyProfileMethodList = new ArrayList<NotifyProfileMethod>();
		notifyProfileMethodDTO = new NotifyProfileMethodDTO();
		notifyProfileMethodDTOs = new ArrayList<NotifyProfileMethodDTO>();
		notifyMethodId = 123L;
		notificationName = "BAD ORDER";
		notifyProfileMethod.setNotifyMethodId(notifyMethodId);
		notifyProfileMethodDTO.setNotifyMethodId(notifyMethodId);
		notifyProfileMethod.setNotificationName(notificationName);
		notifyProfileMethodDTO.setNotificationName(notificationName);
		
		header = new HashMap<String, String>();
		header.put("userid", "Test");
		header.put("extensionschema", "Test");
	}
	
	@AfterEach
	void tearDown() throws Exception {
		notifyProfileMethod = null;
		notifyProfileMethodList = null;
		notifyProfileMethodDTO = null;
		notifyProfileMethodDTOs = null;
	}
	
	@Test
	void testInsertCustomerNotifyProfile() {
		when(notifyProfileMethodRepository.existsByNotifyMethodId(Mockito.any())).thenReturn(true);
		when(notifyProfileMethodRepository.save(Mockito.any())).thenReturn(notifyProfileMethod);
		NotifyProfileMethod addedNotifyProfileMethod = notifyProfileMethodService
				.insertNotifyProfileMethod(notifyProfileMethod, notifyProfileMethodDTO, header);
		assertEquals(addedNotifyProfileMethod, notifyProfileMethod);
	}

	@Test
	void testUpdateCustomerNotifyProfile() {
		when(notifyProfileMethodRepository.existsByNotifyMethodId(Mockito.any())).thenReturn(true);
		when(notifyProfileMethodRepository.save(Mockito.any())).thenReturn(notifyProfileMethod);
		updatedNotifyProfileMethod = notifyProfileMethodService.updateNotifyProfileMethod(notifyProfileMethodDTO, header);
		assertEquals(updatedNotifyProfileMethod, updatedNotifyProfileMethod);
	}
}
