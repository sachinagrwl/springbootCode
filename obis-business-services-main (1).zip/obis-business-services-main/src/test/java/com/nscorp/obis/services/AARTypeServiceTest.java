package com.nscorp.obis.services;

import com.nscorp.obis.domain.AARType;
import com.nscorp.obis.dto.AARTypeDTO;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.repository.AARTypeRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

class AARTypeServiceTest {
	
	@InjectMocks
	AARTypeServiceImpl aarTypeService;

	@Mock
	AARTypeRepository aarTypeRepository;
	
	AARType aarType;
	AARTypeDTO aarTypeDto;
	List<AARType> aarTypeList;
	List<AARTypeDTO> aarTypeDTOList;
	List<String> search;

	AARType addedTable;
	AARType tableUpdated;
	Map<String, String> header;
	String type;
	String type2;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		aarType = new AARType();
		aarType.setAarCapacity(1);
		aarType.setAarType("P110");
		aarType.setAarDescription("DEMO");
		aarType.setImDescription("Demo");
		aarType.setStandardAarType("Demo");
		aarTypeList = new ArrayList<>();

		aarTypeList.add(aarType);
		aarTypeDto = new AARTypeDTO();
		aarTypeDto.setAarCapacity(1);
		aarTypeDto.setAarType("P110");
		aarTypeDto.setAarDescription("DEMO");
		aarTypeDto.setImDescription("Demo");
		aarTypeDto.setStandardAarType("Demo");
		aarTypeDTOList = new ArrayList<>();
		aarTypeDTOList.add(aarTypeDto);
		type = "car";
		type2 = "freight";

		search = new ArrayList<>();
		search.add("P");
		search.add("Q");
		search.add("S");
	}

	@AfterEach
	void tearDown() throws Exception {
		aarType = null;
		aarTypeDto = null;
		aarTypeDTOList = null;
		aarTypeList = null;
	}

	@Test
	void testGetAllAARTypes() {
		when(aarTypeRepository.findByAarTypeStartsWith("P")).thenReturn(aarTypeList);
		List<AARType> aarTypes = aarTypeService.getAllAARTypes(type);
		assertEquals(aarTypes,aarTypeList);
	}

	@Test
	void testGetFreightAARTypes() {
		when(aarTypeRepository.findByAarTypeStartsWith("U")).thenReturn(aarTypeList);
		List<AARType> aarTypes = aarTypeService.getAllAARTypes(type2);
		assertEquals(aarTypes,aarTypeList);
	}

	@Test
	void testGetAllAARTypesException(){
		NoRecordsFoundException exception = assertThrows(NoRecordsFoundException.class,
				() -> when(aarTypeService.getAllAARTypes(Mockito.anyString())));
		Assertions.assertEquals("No Records found for AAR Type!", exception.getMessage());
	}

}
