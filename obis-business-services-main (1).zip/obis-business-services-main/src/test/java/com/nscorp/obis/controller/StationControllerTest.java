package com.nscorp.obis.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import com.nscorp.obis.domain.Station;
import com.nscorp.obis.dto.StationDTO;
import com.nscorp.obis.dto.mapper.StationMapper;
import com.nscorp.obis.response.APIResponse;
import com.nscorp.obis.response.PaginationWrapper;
import com.nscorp.obis.services.StationService;

class StationControllerTest {
	
	@Mock
	StationService stationService;

	@Mock
	StationMapper stationMapper;

	@InjectMocks
	StationController stationController;

	StationDTO stationDto;
	Station station;
	List<Station> stationList;
	Page<Station> stationPageList;
	List<StationDTO> stationDtoList;
	PaginationWrapper paginationWrapper;

	Map<String, String> header;
	
	Pageable pageable;
	
	int pageNumber;
	int pageSize;
	String[] sort;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
		station = new Station();
		station.setTermId((long) 1.8245946233393E13);
		station.setStationName("LOGISTIK");
		station.setState("SL");
		station.setSplc("919426000");
		station.setRule260Station("CNTRA");
		station.setRoadNumber("0978");
		station.setRoadName("KCSM");
		station.setOperationStation("92457");
		station.setIntermodalIndicator("O");
		station.setFSAC("092457");
		station.setExpiredDate(null);
		station.setExpirationDate(null);
		station.setDivision("74");
		station.setChar8Spell("HUMPREPA");
		station.setChar5Spell("GREGC");
		station.setChar5Alias(null);
		station.setBottomPick("Y");
		station.setTopPick("Y");
		station.setBillingInd(null);
		station.setBillAtFsac("071619");
		
		stationList = new ArrayList<>();
		stationList.add(station);
		
		stationDto = new StationDTO();
		stationDto.setTermId((long) 1.8245946233393E13);
		stationDto.setStationName("LOGISTIK");
		stationDto.setState("SL");
		stationDto.setSplc("919426000");
		stationDto.setRule260Station("CNTRA");
		stationDto.setRoadNumber("0978");
		stationDto.setRoadName("KCSM");
		stationDto.setOperationStation("92457");
		stationDto.setIntermodalIndicator("O");
		stationDto.setFSAC("092457");
		stationDto.setExpiredDate(null);
		stationDto.setExpirationDate(null);
		stationDto.setDivision("74");
		stationDto.setChar8Spell("HUMPREPA");
		stationDto.setChar5Spell("GREGC");
		stationDto.setChar5Alias(null);
		stationDto.setBottomPick("Y");
		stationDto.setTopPick("Y");
		stationDto.setBillingInd(null);
		stationDto.setBillAtFsac("071619");
		
		
		stationDtoList = new ArrayList<>();
		stationDtoList.add(stationDto);
		
		header = new HashMap<String, String>();
		header.put("userid", "Test");
		header.put("extensionschema", "Test");
	
		pageNumber = 1;
		pageSize = 10;
		sort = new String[]{"state,desc"};
	}

	@AfterEach
	void tearDown() throws Exception {
		
		station = null;
		stationDto = null;
		stationList = null;
		stationDtoList = null;
		
	}

	@Test
	void testSearchStations() {
		when(stationService.searchStations(stationDto.getStationName(), stationDto.getState(), stationDto.getRoadNumber(), stationDto.getFSAC(), stationDto.getBillAtFsac(), stationDto.getRoadName(),
				stationDto.getOperationStation(), stationDto.getSplc(), stationDto.getRule260Station(), stationDto.getIntermodalIndicator(), stationDto.getChar5Spell(), stationDto.getChar5Alias(),
				stationDto.getChar8Spell(), stationDto.getDivision(), (Date) stationDto.getExpirationDate(), pageable)).thenReturn(stationPageList);
		ResponseEntity<APIResponse<PaginationWrapper>> stationList = stationController.searchStations(stationDto.getStationName(), stationDto.getState(), stationDto.getRoadNumber(), stationDto.getFSAC(), stationDto.getBillAtFsac(), stationDto.getRoadName(),
				stationDto.getOperationStation(), stationDto.getSplc(), stationDto.getRule260Station(), stationDto.getIntermodalIndicator(), stationDto.getChar5Spell(), stationDto.getChar5Alias(),
				stationDto.getChar8Spell(), stationDto.getDivision(), (Date) stationDto.getExpirationDate(), pageNumber, pageSize, sort);
		assertNotNull(stationList.getBody());
	}

	@Test
	void testUpdateStation() {
		when(stationMapper.stationDTOToStation(Mockito.any())).thenReturn(station);
		when(stationService.updateStation(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(station);
		when(stationMapper.stationToStationDTO(Mockito.any())).thenReturn(stationDto);	
		ResponseEntity<APIResponse<StationDTO>> stationUpdated = stationController.updateStation(stationDto, header);
		assertNotNull(stationUpdated.getBody());
	}

}
