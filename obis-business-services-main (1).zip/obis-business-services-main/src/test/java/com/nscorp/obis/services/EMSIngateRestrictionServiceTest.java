package com.nscorp.obis.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.nscorp.obis.domain.DayOfWeek;
import com.nscorp.obis.domain.EMSEquipmentLengthRestriction;
import com.nscorp.obis.domain.EMSIngateRestriction;
import com.nscorp.obis.domain.EquipmentType;
import com.nscorp.obis.domain.LineOfBusiness;
import com.nscorp.obis.domain.TrafficType;
import com.nscorp.obis.domain.WeightQualifier;
import com.nscorp.obis.dto.EMSIngateRestrictionDTO;
import com.nscorp.obis.repository.EMSIngateRestrictionRepository;

class EMSIngateRestrictionServiceTest {

	@InjectMocks
	EMSIngateRestrictionServiceImpl emsIngateRestrictionService;

	@Mock
	EMSIngateRestrictionRepository emsIngateRestrictionRepository;
	
	EMSIngateRestrictionDTO emsIngateRestrictionDto;
	EMSIngateRestriction emsIngateRestriction;
	List<EMSIngateRestriction> emsIngateRestrictionList;
	List<EMSIngateRestrictionDTO> emsIngateRestrictionDtoList;
	Map<String, String> header;
	Long ingateTerminalId = 16535306729700L;
	List<LineOfBusiness> lob = new ArrayList<>(EnumSet.allOf(LineOfBusiness.class));
	List<EquipmentType> eqTp = new ArrayList<>(EnumSet.allOf(EquipmentType.class));
	List<DayOfWeek> days = new ArrayList<>(EnumSet.allOf(DayOfWeek.class));
	List<TrafficType> trafficType = new ArrayList<>(EnumSet.allOf(TrafficType.class));
	List<EMSEquipmentLengthRestriction> lengthRestriction = new ArrayList<>(EnumSet.allOf(EMSEquipmentLengthRestriction.class));
	LocalDate startDate = LocalDate.parse("2020-09-22");
	LocalDate endDate = LocalDate.parse("2020-12-22");
	LocalTime startTime = LocalTime.parse("00:00:00");
	LocalTime endTime = LocalTime.parse("23:59:59");
	Timestamp ts = Timestamp.valueOf(String.format("%04d-%02d-%02d 00:00:00", 
            2022, 07, 01));
	Timestamp ts1 = Timestamp.valueOf(String.format("%04d-%02d-%02d 00:00:00", 
            2022, 05, 01));
	
	EMSIngateRestriction addedEMSRestrictions;
	EMSIngateRestriction updatedEMSRestrictions;
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		emsIngateRestriction = new EMSIngateRestriction();
		emsIngateRestrictionDto = new EMSIngateRestrictionDTO();
		emsIngateRestrictionDtoList = new ArrayList<>();
		emsIngateRestrictionList = new ArrayList<>();
		emsIngateRestrictionDto.setRestrictId(12345L);
		emsIngateRestrictionDto.setIngateTerminalId(ingateTerminalId);
		emsIngateRestrictionDto.setOnlineOriginStationTermId(99990010179947L);
		emsIngateRestrictionDto.setOnlineDestinationStationTermId(9096615681588L);
		emsIngateRestrictionDto.setOfflineDestinationStationTermId(null);
		emsIngateRestrictionDto.setEquipmentInit(null);
		emsIngateRestrictionDto.setEquipmentLowestNumber(1234);
		emsIngateRestrictionDto.setEquipmentHighestNumber(1234);
		emsIngateRestrictionDto.setCorporateCustomerId(null);
		emsIngateRestrictionDto.setPrimaryLineOfBusiness(null);
		emsIngateRestrictionDto.setEquipmentType(null);
		emsIngateRestrictionDto.setLoadEmptyCode("L");
		emsIngateRestrictionDto.setEquipmentLength(240);
		emsIngateRestrictionDto.setGrossWeight(100);
		emsIngateRestrictionDto.setLineOfBusinesses(lob);
		emsIngateRestrictionDto.setEquipmentTypes(eqTp);
		emsIngateRestrictionDto.setWayBillRoute(null);
		emsIngateRestrictionDto.setHazardousIndicator(true);
		emsIngateRestrictionDto.setWeightQualifier(WeightQualifier.GE);
		emsIngateRestrictionDto.setActive("T");
		emsIngateRestrictionDto.setStartDate(startDate);
		emsIngateRestrictionDto.setEndDate(endDate);
		emsIngateRestrictionDto.setStartTime(startTime);
		emsIngateRestrictionDto.setEndTime(endTime);
		emsIngateRestrictionDto.setCreateExtensionSchema("IMS08121");
		emsIngateRestrictionDto.setRestrictedDays(days);
		emsIngateRestrictionDto.setTrafficTypes(trafficType);
		emsIngateRestrictionDto.setReeferIndicator(false);
		emsIngateRestrictionDto.setTemperoryIndicator("T");
		emsIngateRestrictionDto.setEmsEquipmentLengthRestrictions(lengthRestriction);
		emsIngateRestrictionDto.setUversion("!");
		emsIngateRestrictionDto.setCreateUserId("MST0U");
		emsIngateRestrictionDto.setCreateDateTime(ts);
		//emsIngateRestrictionDto.setUpdateDateTime(ts1);
		emsIngateRestrictionDto.setUpdateUserId("MST0U");
		emsIngateRestrictionDto.setUpdateExtensionSchema("IMS08121");
		emsIngateRestrictionDtoList.add(emsIngateRestrictionDto);
		header = new HashMap<String,String>();
		header.put("userid", "Test");
		header.put("extensionschema", "Test");
	}

	@AfterEach
	void tearDown() throws Exception {
		emsIngateRestrictionList = null;
		emsIngateRestrictionDtoList = null;
		emsIngateRestrictionDto = null;
		emsIngateRestriction = null;
	}

	@Test
	void testGetAllRestrictions() {
		try {
			when(emsIngateRestrictionRepository.findAll()).thenReturn(emsIngateRestrictionList);
			List<EMSIngateRestriction> allEMSRestrictions = emsIngateRestrictionService.getAllRestrictions();
			assertEquals(allEMSRestrictions,emsIngateRestrictionList);
		} catch (Exception e) {
			e.getMessage();
		}
	}
	
	@Test
	void testInsertRestriction() {
		try {
			when(emsIngateRestrictionRepository.save(any(EMSIngateRestriction.class))).thenReturn(emsIngateRestriction);
			EMSIngateRestriction rectrictionAdded = emsIngateRestrictionService.insertRestriction(emsIngateRestriction, "Test", "Test");
			assertEquals(rectrictionAdded.getIngateTerminalId(), emsIngateRestriction.getIngateTerminalId());
		} catch (Exception e) {
			e.getMessage();
		}
	}
	
	@Test
	void testUpdateRestriction() {
		try {
			when(emsIngateRestrictionRepository.save(any(EMSIngateRestriction.class))).thenReturn(emsIngateRestriction);
			EMSIngateRestriction rectrictionUpdated = emsIngateRestrictionService.updateRestriction(emsIngateRestriction, "Test", "Test");
			assertEquals(rectrictionUpdated.getIngateTerminalId(), emsIngateRestriction.getIngateTerminalId());
		} catch (Exception e) {
			e.getMessage();
		}
	}

}
