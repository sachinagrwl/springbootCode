package com.nscorp.obis.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.nscorp.obis.domain.ShiplineCustomer;
import com.nscorp.obis.dto.ShiplineCustomerDTO;
import com.nscorp.obis.dto.mapper.ShiplineCustomerMapper;
import com.nscorp.obis.response.APIResponse;
import com.nscorp.obis.services.ShiplineCustomerService;

class ShiplineCustomerControllerTest {
	@Mock
	ShiplineCustomerService steamshipCustomerService;

	@Mock
	ShiplineCustomerMapper steamshipCustomerMapper;

	@InjectMocks
	ShiplineCustomerController steamshipCustomerController;
	
	ShiplineCustomerDTO steamshipCustomerDto;
	ShiplineCustomer steamshipCustomer;
	List<ShiplineCustomer> steamshipCustomerList;
	List<ShiplineCustomerDTO> steamshipCustomerDtoList;
	Map<String, String> header;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		steamshipCustomer = new ShiplineCustomer();
		steamshipCustomerDto = new ShiplineCustomerDTO();
		steamshipCustomerDtoList = new ArrayList<>();
		steamshipCustomerList = new ArrayList<>();
		steamshipCustomerDto.setShiplineNumber("123AB");
		steamshipCustomerDto.setCustomerId((long) 123.000);
		steamshipCustomerDto.setDescription("TEST");
		steamshipCustomer.setShiplineNumber("123AB");
		steamshipCustomer.setCustomerId((long) 123.000);
		steamshipCustomer.setDescription("TEST");
		steamshipCustomerDtoList.add(steamshipCustomerDto);
		steamshipCustomerList.add(steamshipCustomer);
		header = new HashMap<String,String>();
		header.put("userid", "Test");
		header.put("extensionschema", "Test");
	}

	@AfterEach
	void tearDown() throws Exception {
		steamshipCustomer = null;
		steamshipCustomerDto = null;
		steamshipCustomerDtoList = null;
		steamshipCustomerList = null;
	}

	@Test
	void testGetAllSteamshipCustomer() {
		when(steamshipCustomerService.getAllSteamshipCustomers()).thenReturn(steamshipCustomerList);
		ResponseEntity<APIResponse<List<ShiplineCustomerDTO>>> getSteamshipCustomersList = steamshipCustomerController.getAllSteamshipCustomer();
		//assertEquals(getSteamshipCustomersList.getBody(), steamshipCustomerDtoList);
		assertNotNull(getSteamshipCustomersList.getBody());
	}

	@Test
	void testAddSteamshipCustomer() {
		when(steamshipCustomerMapper.steamshipCustomerDTOToSteamshipCustomer(Mockito.any())).thenReturn(steamshipCustomer);
		when(steamshipCustomerService.addSteamshipCustomer(Mockito.any(), Mockito.any())).thenReturn(steamshipCustomer);
		when(steamshipCustomerMapper.steamshipCustomerToSteamshipCustomerDTO(Mockito.any())).thenReturn(steamshipCustomerDto);
		ResponseEntity<APIResponse<ShiplineCustomerDTO>> addedSteamshipCustomer = steamshipCustomerController.addSteamshipCustomer(steamshipCustomerDto, header);
		assertNotNull(addedSteamshipCustomer.getBody());
	}
	

	@Test
	void testDeleteSteamshipCustomer() {
		steamshipCustomerService.deleteCustomer(steamshipCustomer);
		//doNothing().when(steamshipCustomerService).deleteCustomer(steamshipCustomerList);;
		steamshipCustomerController.deleteSteamshipCustomer(steamshipCustomerDtoList);
	}


}
