package com.nscorp.obis.services;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.nscorp.obis.domain.Station;
import com.nscorp.obis.dto.StationDTO;
import com.nscorp.obis.repository.StationRepository;

class StationServiceTest {
	
	@InjectMocks
	StationServiceImpl stationService;

	@Mock
	StationRepository stationRepository;
	
	Station station;
	Station stationResource;
	StationDTO stationDto;
	List<Station> stationList;
	Page<Station> stationPageList;
	Station stationUpdated;
	
	Pageable pageable;
	
	int pageNumber;
	int pageSize;
	
	String userid = "Test";
	String extensionschema =  "Test";
	
	Map<String, String> header;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
		station = new Station();
		station.setTermId((long) 1.8245946233393E13);
		station.setStationName("LOGISTIK");
		station.setState("SL");
		station.setSplc("919426000");
		station.setRule260Station("CNTRA");
		station.setRoadNumber("0978");
		station.setRoadName("KCSM");
		station.setOperationStation("92457");
		station.setIntermodalIndicator("O");
		station.setFSAC("092457");
		station.setExpiredDate(null);
		station.setExpirationDate(null);
		station.setDivision("74");
		station.setChar8Spell("HUMPREPA");
		station.setChar5Spell("GREGC");
		station.setChar5Alias(null);
		station.setBottomPick("Y");
		station.setTopPick("Y");
		station.setBillingInd(null);
		station.setBillAtFsac("071619");
		
		stationList = new ArrayList<>();
		
		stationDto = new StationDTO();
		stationDto.setTermId((long) 1.8245946233393E13);
		stationDto.setStationName("LOGISTIK");
		stationDto.setState("SL");
		stationDto.setSplc("919426000");
		stationDto.setRule260Station("CNTRA");
		stationDto.setRoadNumber("0978");
		stationDto.setRoadName("KCSM");
		stationDto.setOperationStation("92457");
		stationDto.setIntermodalIndicator("O");
		stationDto.setFSAC("092457");
		stationDto.setExpiredDate(null);
		stationDto.setExpirationDate(null);
		stationDto.setDivision("74");
		stationDto.setChar8Spell("HUMPREPA");
		stationDto.setChar5Spell("GREGC");
		stationDto.setChar5Alias(null);
		stationDto.setBottomPick("Y");
		stationDto.setTopPick("Y");
		stationDto.setBillingInd(null);
		stationDto.setBillAtFsac("071619");
		
		stationResource = new Station();
		stationResource.setTermId((long) 1.8245946233393E13);
		stationResource.setStationName("LOGISTIK");
		stationResource.setState("SL");
		stationResource.setSplc("919426000");
		stationResource.setRule260Station("CNTRA");
		stationResource.setRoadNumber("0978");
		stationResource.setRoadName("KCSM");
		stationResource.setOperationStation("92457");
		stationResource.setIntermodalIndicator("O");
		stationResource.setFSAC("092457");
		stationResource.setExpiredDate(null);
		stationResource.setExpirationDate(null);
		stationResource.setDivision("74");
		stationResource.setChar8Spell("HUMPREPA");
		stationResource.setChar5Spell("GREGC");
		stationResource.setChar5Alias(null);
		stationResource.setBottomPick("Y");
		stationResource.setTopPick("Y");
		stationResource.setBillingInd(null);
		stationResource.setBillAtFsac("071619");
		
		
		header = new HashMap<String, String>();
		header.put("userid", "Test");
		header.put("extensionschema", "Test");
	
		pageNumber = 1;
		pageSize = 10;
	}

//	@AfterEach
//	void tearDown() throws Exception {
//
//	}

	@Test
	void testSearchStations() {
		try {
			when(stationRepository.searchAll(stationDto.getStationName(), stationDto.getState(), stationDto.getRoadNumber(), stationDto.getFSAC(), stationDto.getBillAtFsac(), stationDto.getRoadName(),
					stationDto.getOperationStation(), stationDto.getSplc(), stationDto.getRule260Station(), stationDto.getIntermodalIndicator(), stationDto.getChar5Spell(), stationDto.getChar5Alias(),
					stationDto.getChar8Spell(), stationDto.getDivision(), (Date) stationDto.getExpirationDate(), pageable)).thenReturn(stationPageList);
			Page<Station> allStations = stationService.searchStations(stationDto.getStationName(), stationDto.getState(), stationDto.getRoadNumber(), stationDto.getFSAC(), stationDto.getBillAtFsac(), stationDto.getRoadName(),
					stationDto.getOperationStation(), stationDto.getSplc(), stationDto.getRule260Station(), stationDto.getIntermodalIndicator(), stationDto.getChar5Spell(), stationDto.getChar5Alias(),
					stationDto.getChar8Spell(), stationDto.getDivision(), (Date) stationDto.getExpirationDate(), pageable);
			assertEquals(allStations, stationPageList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}	
	}

	@Test
	void testUpdateStation() {
		try {
			when(stationRepository.searchAll("LOGISTIK", stationDto.getState(), stationDto.getRoadNumber(), stationDto.getFSAC(), stationDto.getBillAtFsac(), stationDto.getRoadName(),
						stationDto.getOperationStation(), stationDto.getSplc(), stationDto.getRule260Station(), stationDto.getIntermodalIndicator(), stationDto.getChar5Spell(), stationDto.getChar5Alias(),
						stationDto.getChar8Spell(), stationDto.getDivision(), (Date) stationDto.getExpirationDate(), pageable)).thenReturn(stationPageList);
			stationUpdated = stationService.updateStation(station, userid, extensionschema);
			assertEquals(stationUpdated, station);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}

	}

}
