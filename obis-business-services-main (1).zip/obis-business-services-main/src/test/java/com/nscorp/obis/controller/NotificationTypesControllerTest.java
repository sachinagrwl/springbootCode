package com.nscorp.obis.controller;



import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.nscorp.obis.services.NotificationTypesService;
import com.nscorp.obis.dto.NotificationTypesResponseDTO;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.response.APIResponse;



public class NotificationTypesControllerTest {
	
	@Mock
	NotificationTypesService notificationTypesService;

	@InjectMocks
	NotificationTypesController notificationTypesController;
	
	
	NotificationTypesResponseDTO notificationTypesResponseDTO;
	List<NotificationTypesResponseDTO> notificationTypesResponseDTOList;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setup() throws Exception{
		MockitoAnnotations.initMocks(this);
		
		notificationTypesResponseDTO = new NotificationTypesResponseDTO();
		notificationTypesResponseDTOList = new ArrayList<>();
		
	}
	
	@AfterEach
	void tearDown() throws Exception{
		
		notificationTypesResponseDTO = null;
		notificationTypesResponseDTOList= null;
	}
	
	@Test
	void testGetNotificationTypes() throws SQLException{
		when(notificationTypesService.fetchNotificationTypes()).thenReturn(notificationTypesResponseDTOList);
		ResponseEntity<APIResponse<List<NotificationTypesResponseDTO>>> notificationTypesResponseDTO = notificationTypesController.getNotificationTypes();
		assertEquals(notificationTypesResponseDTO.getBody().getData(),notificationTypesResponseDTOList);
		assertEquals(notificationTypesResponseDTO.getStatusCodeValue(),200);		
	}
	@Test
	void testNoRecordsFoundException() throws SQLException {
		when(notificationTypesService.fetchNotificationTypes()).thenThrow(new NoRecordsFoundException());
		ResponseEntity<APIResponse<List<NotificationTypesResponseDTO>>> notificationTypesResponseDTO = notificationTypesController.getNotificationTypes();
		assertEquals(notificationTypesResponseDTO.getStatusCodeValue(),404);
	}
}
