package com.nscorp.obis.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nscorp.obis.domain.Pool;

public interface PoolRepository extends JpaRepository<Pool,Long>{


	Pool getByPoolName(String poolName);

	//void deleteByPoolId(Double poolId);

	

}
