package com.nscorp.obis.services;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nscorp.obis.common.UserId;
import com.nscorp.obis.domain.Block;
import com.nscorp.obis.exception.InvalidDataException;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.repository.BlockRepository;


@Service
@Transactional
public class BlockServiceImpl implements BlockService {

	@Autowired(required = true)
	private BlockRepository blockRepo;

	public List<Block> getAllBlocks(Double termId, String trainNr) {
		List<Block> blockList = blockRepo.findByTermIdAndTrainNr(termId, trainNr);
		if (blockList.isEmpty()) {
			throw new NoRecordsFoundException("No records found");
		}
		return blockList;
	}

	@Override
	public Block updateBlock(Block blockObj, Map<String, String> headers) {

		UserId.headerUserID(headers);
		if (blockRepo.existsByBlockId(blockObj.getBlockId())) {
			Block block = blockRepo.findByBlockId(blockObj.getBlockId());
			block.setUpdateUserId(headers.get("userid"));
			// block.setUpdateExtensionSchema(extensionSchema);
			//block.setBlockId(blockObj.getBlockId());
			block.setBlockNm(blockObj.getBlockNm());
			block.setBlockOrder(blockObj.getBlockOrder());
			block.setAllowSameCar(blockObj.getAllowSameCar());
			block.setBlockPriority(blockObj.getBlockPriority());
			// block.setSwInterchange(blockObj.getSwInterchange());
			block.setAllowSameCar(blockObj.getAllowSameCar());
			if (blockObj.getHightFeet() != null) {

				if (blockObj.getHightFeet() >= 13 && blockObj.getHightFeet() <= 20) {

					if (blockObj.getHightFeet() >= 13 && blockObj.getHightFeet() <= 17) {

						if (blockObj.getHightFeet() == 13) {
							if (blockObj.getHightInches() == null) {
								throw new InvalidDataException("Inches should between 6 to 9 ");
							} else if (blockObj.getHightInches() >= 6 && blockObj.getHightInches() <= 9) {
								block.setHightFeet(blockObj.getHightFeet());
							}

							else
								throw new InvalidDataException("Inches should between 6 to 9 ");

						} else if (blockObj.getHightFeet() >= 14 && blockObj.getHightFeet() <= 16) {
							if (blockObj.getHightInches() == null) {
								throw new InvalidDataException("Inches should between 0 to 9 ");

							} else if (blockObj.getHightInches() >= 0 && blockObj.getHightInches() <= 9)
								block.setHightFeet(blockObj.getHightFeet());
							else
								throw new InvalidDataException("Inches should between 0 to 9 ");
						}

						else if (blockObj.getHightFeet() == 17) {
							if (blockObj.getHightInches() == null) {
								throw new InvalidDataException("Inches should be less than 6 ");

							} else if (blockObj.getHightInches() <= 6)
								block.setHightFeet(blockObj.getHightFeet());

							else
								throw new InvalidDataException("Inches should be less than 6 ");
						}
					} else if (blockObj.getHightFeet() == 18 || blockObj.getHightFeet() == 19
							|| blockObj.getHightFeet() == 20) {
						if (blockObj.getHightInches() == null) {
							throw new InvalidDataException("Inches should be 3 ");

						} else if ((blockObj.getHightInches() == 3)) {
							block.setHightFeet(blockObj.getHightFeet());
							block.setHightInches(blockObj.getHightInches());
						} else
							throw new InvalidDataException("Inches should be 3 ");
					}

				} else {
					throw new InvalidDataException("Hight Feet should between 13 to 20 ");
				}
			} else if (blockObj.getHightFeet() == null) {
				if (blockObj.getHightInches() == null) {
					block.setHightInches(blockObj.getHightInches());
					block.setHightFeet(blockObj.getHightFeet());
				} else

					throw new InvalidDataException("Only null value accepted for Inches ");
			} else

				throw new InvalidDataException("Enter the values correctly ");

			block.setBlockMon(blockObj.getBlockMon());
			block.setBlockTue(blockObj.getBlockTue());
			block.setBlockWed(blockObj.getBlockWed());
			block.setBlockThu(blockObj.getBlockThu());
			block.setBlockFri(blockObj.getBlockFri());
			block.setBlockSat(blockObj.getBlockSat());
			block.setBlockSun(blockObj.getBlockSun());
			blockRepo.save(block);
			return block;
		} else {
			throw new NoRecordsFoundException("Record with BlockID " + blockObj.getBlockId() + " Not Found!");

		}

	}
}