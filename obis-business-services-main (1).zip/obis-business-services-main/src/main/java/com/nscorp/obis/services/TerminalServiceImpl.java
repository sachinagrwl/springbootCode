package com.nscorp.obis.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nscorp.obis.domain.Terminal;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.repository.TerminalRepository;

@Service
public class TerminalServiceImpl implements TerminalService{

	@Autowired
	private TerminalRepository terminalRepo;
	
	@Override
	public List<Terminal> getAllTerminals() {

//		List<Terminal> terminals = terminalRepo.findAllByOrderByTerminalNameAsc();
		List<Terminal> terminals = terminalRepo.fetchAllActiveTerminals();
		if(terminals.isEmpty()) {
			throw new NoRecordsFoundException("No Records are found for Terminal");
		}
		return terminals;
	}

}
