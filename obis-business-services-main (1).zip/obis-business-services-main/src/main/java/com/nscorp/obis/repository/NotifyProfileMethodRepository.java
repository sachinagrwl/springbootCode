package com.nscorp.obis.repository;

import java.util.List;

import javax.validation.Valid;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nscorp.obis.domain.NotifyProfileMethod;

@Repository
public interface NotifyProfileMethodRepository extends JpaRepository<NotifyProfileMethod, Long> {

	Page<NotifyProfileMethod> findAll(Specification<NotifyProfileMethod> specification, Pageable pageable);
	
	NotifyProfileMethod findByNotifyMethodId(@Valid long notifyMethodId);

	List<NotifyProfileMethod> findAll(Specification<NotifyProfileMethod> specs);

	boolean existsByNotifyMethodId(Long notifyMethodId);
	

}
