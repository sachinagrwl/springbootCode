package com.nscorp.obis.dto.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.nscorp.obis.domain.AuditInfo;
import com.nscorp.obis.dto.AuditInfoDTO;

@Mapper(componentModel = "spring")
public interface AuditInfoMapper {

	AuditInfoMapper INSTANCE = Mappers.getMapper(AuditInfoMapper.class);

	AuditInfoDTO auditInfoToAuditInfoDTO(AuditInfo auditInfo);

	AuditInfo auditInfoDTOToAuditInfo(AuditInfoDTO auditInfoDTO);
}
