package com.nscorp.obis.domain;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "TEMP_METERING")
public class EMSIngateAllocation extends BaseEMSIngateRestriction {

	@Id
	@Column(name = "TIMS_ID", length = 19, columnDefinition = "double", nullable = false)
	private Long timsId;

	@Column(name = "ALLOTMENT_TYPE", columnDefinition = "char(1)", nullable = true)
	private EMSAllotmentType allotmentType;

	@Column(name = "INGT_ALLOW", columnDefinition = "Integer", nullable = true)
	private Integer totalIngatesAllowed;

	@Column(name = "NR_INGT", columnDefinition = "Integer", nullable = true)
	private Integer numberIngated;

	public EMSIngateAllocation() {
	}

//	public EMSIngateAllocation(String uversion, String createUserId, Object createDateTime, String updateUserId,
//			Object updateDateTime, String updateExtensionSchema, Long timsId, Long ingateTerminalId,
//			Long onlineOriginStationTermId, Station onlineOriginStation, Long onlineDestinationStationTermId,
//			Station onlineDestinationStation, Long offlineDestinationStationTermId, Station offlineDestinationStation,
//			String equipmentInit, Integer equipmentLowestNumber, Integer equipmentHighestNumber,
//			Long corporateCustomerId, String loadEmptyCode, Integer equipmentLength, Integer grossWeight,
//			List<LineOfBusiness> lineOfBusinesses, List<EquipmentType> equipmentTypes, String wayBillRoute,
//			Boolean hazardousIndicator, WeightQualifier weightQualifier, String active, Object startDate,
//			Object startTime, Object endDate, Object endTime, String createExtensionSchema,
//			List<DayOfWeek> restrictedDays, List<TrafficType> trafficTypes, Boolean reeferIndicator,
//			String temperoryIndicator, String twentyFeet, String fortyFeet, String fortyFiveFeet, String fiftyThreeFeet,
//			String allLengths, EMSAllotmentType allotmentType, Integer totalIngatesAllowed, Integer numberIngated) {
//		super(uversion, createUserId, createDateTime, updateUserId, updateDateTime, updateExtensionSchema,
//				ingateTerminalId, onlineOriginStationTermId, onlineOriginStation, onlineDestinationStationTermId,
//				onlineDestinationStation, offlineDestinationStationTermId, offlineDestinationStation, equipmentInit,
//				equipmentLowestNumber, equipmentHighestNumber, corporateCustomerId, loadEmptyCode, equipmentLength,
//				grossWeight,lineOfBusinesses,equipmentTypes, wayBillRoute, hazardousIndicator, weightQualifier, active, startDate, startTime, endDate,
//				endTime, createExtensionSchema, restrictedDays, trafficTypes, reeferIndicator, temperoryIndicator,
//				twentyFeet, fortyFeet, fortyFiveFeet, fiftyThreeFeet, allLengths);
//		this.timsId = timsId;
//		this.allotmentType = allotmentType;
//		this.totalIngatesAllowed = totalIngatesAllowed;
//		this.numberIngated = numberIngated;
//	}
}