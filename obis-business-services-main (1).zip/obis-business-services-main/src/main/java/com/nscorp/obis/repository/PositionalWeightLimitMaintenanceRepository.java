package com.nscorp.obis.repository;

import java.util.List;

//import org.mockito.stubbing.OngoingStubbing;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nscorp.obis.domain.PositionalWeightLimitMaintenance;
import com.nscorp.obis.domain.PositionalWeightLimitPrimaryKeys;


@Repository
public interface PositionalWeightLimitMaintenanceRepository extends JpaRepository<PositionalWeightLimitMaintenance, PositionalWeightLimitPrimaryKeys> {
			
	List<PositionalWeightLimitMaintenance> findByCarInit(String car_init);

//	List<PositionalWeightLimitMaintenance> findByCarInitAndCarNrLowAndCarNrHighAndCarEquipmentType(String carInit,
//			Double carNrLow, Double carNrHigh, String carEquipmentType);
	
	/* This Method Is Used To Add Values */
	boolean existsByCarInitAndCarNrLowAndCarNrHighAndCarEquipmentType(String carInit, Long carNrLow, Long carNrHigh, String carEquipmentType);

	/* This Method Is Used To Update Values */
	PositionalWeightLimitMaintenance findByCarInitAndCarNrLowAndCarNrHighAndCarEquipmentType(String carInit,
			Long carNrLow, Long carNrHigh, String carEquipmentType);
	
	/* This Method Is Used To Delete Values */
	void deleteByCarInitAndCarNrLowAndCarNrHighAndCarEquipmentType(String carInit, Long carNrLow, Long carNrHigh,
			String carEquipmentType);
	
	/*This method is used in the Junit Delete Functionality*/
//	OngoingStubbing<List<PositionalWeightLimitMaintenance>> findByCarInitAndCarNrLowAndCarNrHighAndCarEquipmentType(
//			Class<PositionalWeightLimitMaintenance> class1);

	

}
