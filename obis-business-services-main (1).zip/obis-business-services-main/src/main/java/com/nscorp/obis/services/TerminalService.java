package com.nscorp.obis.services;

import java.util.List;

import com.nscorp.obis.domain.Terminal;

public interface TerminalService {

	List<Terminal> getAllTerminals();

}
