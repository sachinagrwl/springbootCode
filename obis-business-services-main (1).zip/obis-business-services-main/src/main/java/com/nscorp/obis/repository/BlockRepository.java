package com.nscorp.obis.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nscorp.obis.domain.Block;

@Repository
public interface BlockRepository extends JpaRepository<Block, Double>{
	List<Block> findByTermIdAndTrainNr(Double termId, String trainNr);
	Block findByTermIdAndTrainNrIgnoreCase(Double termId, String trainNr);

	boolean existsByTermIdAndTrainNr(Double termId, String trainNr);

	boolean existsByBlockId(Double blockId);
	Block findByBlockId(Double blockId);
	
	void deleteByTermIdAndTrainNr(Double termId, String trainNr);

	//Block findByBlockId(Double blockId);
}
