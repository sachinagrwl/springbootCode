package com.nscorp.obis.dto.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;


import com.nscorp.obis.domain.Terminal;
import com.nscorp.obis.dto.TerminalDTO;

@Mapper(componentModel = "spring")
public interface TerminalMapper {

	TerminalMapper INSTANCE = Mappers.getMapper(TerminalMapper.class);

	TerminalDTO terminalToTerminalDTO(Terminal terminal);

	Terminal terminalDTOToTerminal(TerminalDTO terminalDTO);
}
