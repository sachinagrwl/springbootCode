package com.nscorp.obis.response;

public enum ResponseStatusCode {

    SUCCESS (100),
    FAILURE (120),
    INFORMATION (110);

    private int statusCode;

    ResponseStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public int getStatusCode() {
        return statusCode;
    }
}
