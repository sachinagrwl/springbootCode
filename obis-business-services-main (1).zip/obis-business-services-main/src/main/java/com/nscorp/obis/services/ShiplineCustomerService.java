package com.nscorp.obis.services;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import com.nscorp.obis.domain.ShiplineCustomer;

public interface ShiplineCustomerService {

	List<ShiplineCustomer> getAllSteamshipCustomers();
	
	ShiplineCustomer addSteamshipCustomer(@Valid ShiplineCustomer steamshipCustomerObj, Map<String,String> headers);
	void deleteCustomer(@Valid ShiplineCustomer steamshipCustomerObj);
}
