package com.nscorp.obis.services;

import java.util.List;
import java.util.Map;

import com.nscorp.obis.common.CommonConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nscorp.obis.domain.Pool;
import com.nscorp.obis.exception.PoolException;
import com.nscorp.obis.repository.PoolRepository;

@Service
public class PoolServiceImpl implements PoolService{
	@Autowired
	private PoolRepository repository;

	@Override
	public Pool insertPool(Pool pool, Map<String,String> headers)throws PoolException{
		// TODO Auto-generated method stub
		try {
			List<Pool> p1= repository.findAll();
			// id=no. of entries in database +1
			int s=p1.size()+1;
			Double id= (double) s;
			if(pool.getPoolId()==null)
				pool.setPoolId(id);
			repository.save(pool);
	        Pool p=repository.getByPoolName(pool.getPoolName());
	    	//p.setUpdateUserId(p.getCreateUserId());
	    	if(headers.get("userid")!=null) {
	    		p.setCreateUserId(headers.get(CommonConstants.USER_ID));
	    	}
	    	if(headers.get("uversion")!=null) {
	    		p.setuVersion(headers.get("uversion"));
	    	}
	    	if(headers.get("extensionschema")!=null) {
	    		p.setUpdateExtentionSchema(headers.get(CommonConstants.EXTENSION_SCHEMA));
	    	}
	    	
//	    	if(userId!=null) {
//	    		p.setCreateUserId(userId);
//	    	}
	        //p.setCreateUserId(userId);
	        p.setUpdateUserId(p.getCreateUserId());
		    repository.save(p);
		    return p;
		}catch(Exception e) {
			//Object obj=pool;
			throw new PoolException("POOL003","couldn't add pool",pool);
		}
		
	}

	@Override
	public List<Pool> getPools() {
		// TODO Auto-generated method stub
		List<Pool> pools=repository.findAll();
		return pools;
	}
   
}
