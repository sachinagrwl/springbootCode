package com.nscorp.obis.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nscorp.obis.domain.StationRestriction;
import com.nscorp.obis.domain.StationRestrictionPrimaryKeys;

@Repository
public interface StationRestrictionRepository extends JpaRepository<StationRestriction, StationRestrictionPrimaryKeys>{
	boolean existsByStationCrossReferenceIdAndCarTypeAndFreightType(long stationCrossReferenceId, String carType,
			String freightType);

	void deleteByStationCrossReferenceIdAndCarTypeAndFreightType(long stationCrossReferenceId, String carType,
			String freightType);

	List<StationRestriction> findByStationCrossReferenceId(Long termId);

}
