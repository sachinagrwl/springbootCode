package com.nscorp.obis.dto.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.nscorp.obis.dto.PositionalWeightLimitMaintenanceDTO;
import com.nscorp.obis.domain.PositionalWeightLimitMaintenance;

@Mapper(componentModel = "spring")
public interface PositionalWeightLimitMaintenanceMapper {
	
	PositionalWeightLimitMaintenanceMapper INSTANCE = Mappers.getMapper(PositionalWeightLimitMaintenanceMapper.class);

	PositionalWeightLimitMaintenanceDTO positionalWeightLimitMaintenanceToPositionalWeightLimitMaintenanceDTO(PositionalWeightLimitMaintenance positionalWeightLimitMaintenance);

	PositionalWeightLimitMaintenance positionalWeightLimitMaintenanceDTOToPositionalWeightLimitMaintenance(PositionalWeightLimitMaintenanceDTO positionalWeightLimitMaintenanceDTO);

}
