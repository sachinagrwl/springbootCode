package com.nscorp.obis.domain;

public enum DaysOfWeek {

	SUNDAY,
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY;

//    private final String code;
//
//    DaysOfWeek(String code) {
//        this.code = code;
//    }
//
//    public String getCode() {
//        return code;
//    }

}
