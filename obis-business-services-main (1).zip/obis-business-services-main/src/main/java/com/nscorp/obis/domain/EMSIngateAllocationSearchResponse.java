package com.nscorp.obis.domain;

import java.util.List;

public interface EMSIngateAllocationSearchResponse {
	String getUversion();
	String getCreateUserId();
	Object getCreateDateTime();
	String getUpdateUserId();
	Object getUpdateDateTime();
	String getUpdateExtensionSchema();
	Long getIngateTerminalId();
	Long getOnlineOriginStationTermId();
	Station getOnlineOriginStation();
	Long getOnlineDestinationStationTermId();
	Station getOnlineDestinationStation();
	Long getOfflineDestinationStationTermId();
	Station getOfflineDestinationStation();
	String getEquipmentInit();
	Integer getEquipmentLowestNumber();
	Integer getEquipmentHighestNumber();
	Long getCorporateCustomerId();
	String getLoadEmptyCode();
	Integer getEquipmentLength();
	Integer getGrossWeight();
	String getDomestic();
//	List<LineOfBusiness> getLineOfBusinesses();
//	List<EquipmentType> getEquipmentTypes();
	String getWayBillRoute();
	Boolean getHazardousIndicator();
	WeightQualifier getWeightQualifier();
	String getActive();
	Object getStartDate();
	Object getStartTime();
	Object getEndDate();
	Object getEndTime();
	String getCreateExtensionSchema();
//	List<DayOfWeek> getRestrictedDays();
//	List<TrafficType> getTrafficTypes();
	Boolean getReeferIndicator();
	String getTemperoryIndicator();
	String getTwentyFeet();
	String getFortyFeet();
	String getFortyFiveFeet();
	String getGiftyThreeFeet();
	String getAllLengths();
}
