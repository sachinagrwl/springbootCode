package com.nscorp.obis.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nscorp.obis.domain.CorporateCustomer;

public interface CorporateCustomerRepository extends JpaRepository<CorporateCustomer, Long>{

//	boolean existsByCorporateShortNameAndCorporateLongName(String shiplineNumber, String description);

	CorporateCustomer findByCorporateShortNameAndCorporateLongName(String shiplineNumber, String description);

	boolean existsByCorporateLongNameAndCustomerId(String description, Long customerId);

	

}
