package com.nscorp.obis.services;

import java.util.List;
import java.util.Map;

import com.nscorp.obis.common.CommonConstants;
import com.nscorp.obis.common.UserId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nscorp.obis.domain.TerminalTrain;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.exception.RecordNotDeletedException;
import com.nscorp.obis.repository.BlockRepository;
import com.nscorp.obis.repository.TerminalTrainRepository;

@Service
@Transactional
public class TerminalTrainServiceImpl implements TerminalTrainService {

	
	
	@Autowired
	private TerminalTrainRepository terminalTrainRepo;
	
	@Autowired
	private BlockRepository blockRepo;
	
	
	/* This Method Is Used To Fetch All Values */
	@Override
	public List<TerminalTrain> getAllTerminalTrains() {
		List<TerminalTrain> terminalTrain= terminalTrainRepo.findAll();
		if(terminalTrain.isEmpty()) {
			throw new NoRecordsFoundException("No records found");
		}
		return terminalTrain;
	}

	
	/* This Method Is Used To Update Values */	
	@Override
	public TerminalTrain updateTrainDesc(TerminalTrain trainDescObj, Map<String, String> headers) {
		UserId.headerUserID(headers);
	
			if(!terminalTrainRepo.existsByTermIdAndTrainNr(trainDescObj.getTermId(),trainDescObj.getTrainNr())) {
				throw new NoRecordsFoundException("No record Found Under this Term Id:"+trainDescObj.getTermId()+" and Train Nr:"+trainDescObj.getTrainNr());
							
			}
			
			
				TerminalTrain existingTrainDesc = terminalTrainRepo.findByTermIdAndTrainNr(trainDescObj.getTermId(),trainDescObj.getTrainNr());			
				//existingTrainDesc.setCreateUserId(headers.get(CommonConstants.USER_ID));
				existingTrainDesc.setUpdateUserId(headers.get(CommonConstants.USER_ID));
				existingTrainDesc.setTrainDesc(trainDescObj.getTrainDesc());
				terminalTrainRepo.save(existingTrainDesc);
				return existingTrainDesc;
			}
	
	@Override
	public void deleteTrain(TerminalTrain terminalTrain) {
		// TODO Auto-generated method stub
		if(terminalTrainRepo.existsByTermIdAndTrainNr(terminalTrain.getTermId(),terminalTrain.getTrainNr())) {
			if(blockRepo.existsByTermIdAndTrainNr(terminalTrain.getTermId().doubleValue(),terminalTrain.getTrainNr())) {
			blockRepo.deleteByTermIdAndTrainNr(terminalTrain.getTermId().doubleValue(),terminalTrain.getTrainNr());
			}
			terminalTrainRepo.deleteByTermIdAndTrainNr(terminalTrain.getTermId(),terminalTrain.getTrainNr());
		}else {
			String rep = terminalTrain.getTermId()  + " and " + terminalTrain.getTrainNr() + " Record Not Found!";
			throw new RecordNotDeletedException(rep);
		}
	}
}
		


	

