package com.nscorp.obis.services;

import java.util.List;

import com.nscorp.obis.domain.CorporateCustomer;

public interface CorporateCustomerService {
	
	List<CorporateCustomer> getAllCorporateCustomers();
}
