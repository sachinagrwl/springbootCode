package com.nscorp.obis.services;

import java.util.List;

import com.nscorp.obis.domain.AARType;

public interface AARTypeService {

	List<AARType> getAllAARTypes(String type);

}
