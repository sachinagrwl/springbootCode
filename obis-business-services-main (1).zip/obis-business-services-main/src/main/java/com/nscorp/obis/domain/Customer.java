package com.nscorp.obis.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="CUSTOMER")
public class Customer extends AuditInfo implements Serializable{
	@Id
	@Column(name = "CUST_ID", columnDefinition = "Double(15)", nullable = false)
	private Long customerId;
	
	@Column(name = "CORP_CUST_ID", columnDefinition = "Double(15)", nullable = true)
	private Double corporateCustomerId;
	
	@Column(name="CUST_NM", columnDefinition="char(35)", nullable = true)
	private String customerName;
	
	@Column(name="CUST_NR", columnDefinition="char(10)", nullable = true)
	private String customerNumber;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CUST_ID")
	private DeliveryDetail deliveryDetail;

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Double getCorporateCustomerId() {
		return corporateCustomerId;
	}

	public void setCorporateCustomerId(Double corporateCustomerId) {
		this.corporateCustomerId = corporateCustomerId;
	}

	public String getCustomerName() {
		if(customerName!=null) {
			return customerName.trim();
		}
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerNumber() {
		if(customerNumber!=null) {
			return customerNumber.trim();
		}
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public DeliveryDetail getDeliveryDetail() {
		return deliveryDetail;
	}

	public void setDeliveryDetail(DeliveryDetail deliveryDetail) {
		this.deliveryDetail = deliveryDetail;
	}

	public Customer(String uversion, String createUserId, Timestamp createDateTime, String updateUserId,
			Timestamp updateDateTime, String updateExtensionSchema, Long customerId, Double corporateCustomerId,
			String customerName, String customerNumber, DeliveryDetail deliveryDetail) {
		super(uversion, createUserId, createDateTime, updateUserId, updateDateTime, updateExtensionSchema);
		this.customerId = customerId;
		this.corporateCustomerId = corporateCustomerId;
		this.customerName = customerName;
		this.customerNumber = customerNumber;
		this.deliveryDetail = deliveryDetail;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(String uversion, String createUserId, Timestamp createDateTime, String updateUserId,
			Timestamp updateDateTime, String updateExtensionSchema) {
		super(uversion, createUserId, createDateTime, updateUserId, updateDateTime, updateExtensionSchema);
		// TODO Auto-generated constructor stub
	}
}
