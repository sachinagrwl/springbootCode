package com.nscorp.obis.controller;

import com.nscorp.obis.common.ControllerConstants;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(ControllerConstants.EMS_INGATE_ALLOCATION)
@Validated
public class EMSIngateAllocationController {

//	@Autowired
//	EMSIngateAllocationService emsIngateAllocationService;
//
//	@GetMapping
//	public ResponseEntity<APIResponse<PaginationWrapper>> searchAllocations(
//			@RequestParam(value = "ingateTerminalId", required = false) Long ingateTerminalId,
//			@RequestParam(value = "onlineOriginStationTermId", required = false) Long onlineOriginStationTermId,
//			@RequestParam(value = "onlineDestinationStationTermId", required = false) Long onlineDestinationStationTermId,
//			@RequestParam(value = "offlineDestinationStationTermId", required = false) Long offlineDestinationStationTermId,
//			@RequestParam(value = "corporateCustomerId", required = false) Long corporateCustomerId,
//			@RequestParam(value = "lineOfBusinesses", required = false) List<LineOfBusiness> lineOfBusinesses,
//			@RequestParam(value = "wayBillRoute", required = false) String wayBillRoute,
////			@RequestParam(value = "trafficTypes", required = false) List<TrafficType> trafficTypes,
//			@RequestParam(value = "startDate", required = false) Date startDate,
//			@RequestParam(value = "endDate", required = false) Date endDate, @RequestParam int pageNumber, // Page
//																											// number
//			@RequestParam int pageSize, @RequestParam(defaultValue = "ingateTerminalId,asc") String[] sort) { // How
//																												// many
//																												// records
//																												// per
//																												// page
//
//		try {
//
//			List<Order> orders = new ArrayList<Order>();
//
//			if (sort[0].equals("null")) {
//				;
//			} else if (!sort[0].contains(",") && sort.length == 2 && (sort[1].equals("asc") || sort[1].equals("ASC")
//					|| sort[1].equals("DESC") || sort[1].equals("desc"))) {
//				orders.add(new Order(getSortDirection(sort[1]), sort[0]));
//			} else {
//				for (String sortOrder : sort) {
//					if (sortOrder.contains(",")) {
//						String[] _sort = sortOrder.split(",");
//						orders.add(new Order(getSortDirection(_sort[1]), _sort[0]));
//					} else {
//						orders.add(new Order(getSortDirection(" "), sortOrder));
//					}
//				}
//			}
//
//			Page<EMSIngateAllocation> allocations = emsIngateAllocationService.searchIngateAllocation(ingateTerminalId,
//					onlineOriginStationTermId, onlineDestinationStationTermId, offlineDestinationStationTermId,
//					corporateCustomerId, lineOfBusinesses, wayBillRoute, startDate, endDate,
//					PageRequest.of(pageNumber - 1, pageSize, Sort.by(orders)));
//
//			List<EMSIngateAllocationDTO> searchResponseList = Collections.emptyList();
//			List<EMSIngateAllocation> allocations1 = allocations.getContent();
//			System.out.println("print : " + allocations);
//			System.out.println("print : " + allocations.getTotalPages());
//
//
//			if (allocations1 != null && !allocations1.isEmpty()) {
//				searchResponseList = allocations1.stream()
//						.map(EMSIngateAllocationMapper.INSTANCE::emsIngateAllocationToEMSIngateAllocationDTO)
//						.collect(Collectors.toList());
//			}
//
//			PaginationWrapper paginationWrapper = new PaginationWrapper(searchResponseList, allocations.getNumber() + 1,
//					allocations.getTotalPages(), allocations.getTotalElements());
//			APIResponse<PaginationWrapper> responseObj = new APIResponse<>(
//					Arrays.asList("Successfully retrieved data!"), paginationWrapper, ResponseStatusCode.SUCCESS);
//			return ResponseEntity.status(HttpStatus.OK).body(responseObj);
//		} catch (DataAccessException | QueryParameterException exception) {
//			APIResponse<PaginationWrapper> responseObj = new APIResponse<>(
//					Arrays.asList("Request Parameter is incorrect!"), ResponseStatusCode.FAILURE);
//			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseObj);
//		} catch (SizeExceedException e) {
//			APIResponse<PaginationWrapper> responseObj = new APIResponse<>(Arrays.asList(e.getMessage()),
//					ResponseStatusCode.FAILURE);
//			return ResponseEntity.status(HttpStatus.LENGTH_REQUIRED).body(responseObj);
//		} catch (NoRecordsFoundException e) {
//			APIResponse<PaginationWrapper> responseObj = new APIResponse<>(Arrays.asList(e.getMessage()),
//					ResponseStatusCode.INFORMATION);
//			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseObj);
//		} catch (Exception e) {
//			APIResponse<PaginationWrapper> responseObj = new APIResponse<>(Arrays.asList(e.getMessage()),
//					ResponseStatusCode.FAILURE);
//			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseObj);
//		}
//	}
//
//	private Sort.Direction getSortDirection(String direction) {
//		if (direction.equals("asc") || direction.equals("ASC")) {
//			return Sort.Direction.ASC;
//		} else if (direction.equals("desc") || direction.equals("DESC")) {
//			return Sort.Direction.DESC;
//		}
//		return Sort.Direction.ASC;
//	}

}
