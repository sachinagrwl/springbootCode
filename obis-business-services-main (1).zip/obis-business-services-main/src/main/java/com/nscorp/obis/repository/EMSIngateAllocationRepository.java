package com.nscorp.obis.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nscorp.obis.domain.EMSIngateAllocation;
import com.nscorp.obis.domain.LineOfBusiness;
import com.nscorp.obis.domain.TrafficType;

@Repository
public interface EMSIngateAllocationRepository extends JpaRepository<EMSIngateAllocation, Long> {

	@Query(value = "SELECT allocation.uversion AS uversion, "
			+ "allocation.createUserId AS createUserId, "
			+ "allocation.createDateTime AS createDateTime, "
			+ "allocation.updateUserId AS updateUserId, "
			+ "allocation.updateDateTime AS updateDateTime, "
			+ "allocation.updateExtensionSchema AS updateExtensionSchema, "
			+ "allocation.timsId AS timsId, "
			+ "allocation.ingateTerminalId AS ingateTerminalId, "
			+ "allocation.onlineOriginStationTermId AS onlineOriginStationTermId, "
			+ "allocation.onlineOriginStation AS onlineOriginStation, "
			+ "allocation.onlineDestinationStationTermId AS onlineDestinationStationTermId, "
			+ "allocation.onlineDestinationStation AS onlineDestinationStation, "
			+ "allocation.offlineDestinationStationTermId AS offlineDestinationStationTermId, "
			+ "allocation.offlineDestinationStation AS offlineDestinationStation, "
			+ "allocation.equipmentInit AS equipmentInit, "
			+ "allocation.equipmentLowestNumber AS equipmentLowestNumber, "
			+ "allocation.equipmentHighestNumber AS equipmentHighestNumber, "
			+ "allocation.corporateCustomerId AS corporateCustomerId, "
			+ "allocation.loadEmptyCode AS loadEmptyCode, "
			+ "allocation.equipmentLength AS equipmentLength, "
			+ "allocation.grossWeight AS grossWeight, "
			+ "allocation.domestic AS domestic, "
//			+ "allocation.lineOfBusinesses AS lineOfBusinesses, "
//			+ "allocation.equipmentTypes.code AS equipmentTypes, "
			+ "allocation.wayBillRoute AS wayBillRoute, "
			+ "allocation.hazardousIndicator AS hazardousIndicator, "
			+ "allocation.weightQualifier AS weightQualifier, "
			+ "allocation.active AS active, "
			+ "allocation.startDate AS startDate, "
			+ "allocation.startTime AS startTime, "
			+ "allocation.endDate AS endDate, "
			+ "allocation.endTime AS endTime, "
			+ "allocation.createExtensionSchema AS createExtensionSchema, "
//			+ "allocation.restrictedDays AS restrictedDays, "
//			+ "allocation.trafficTypes AS trafficTypes, "
			+ "allocation.reeferIndicator AS reeferIndicator, "
			+ "allocation.temperoryIndicator AS temperoryIndicator, "
			+ "allocation.twentyFeet AS twentyFeet, "
			+ "allocation.fortyFeet AS fortyFeet, "
			+ "allocation.fortyFiveFeet AS fortyFiveFeet, "
			+ "allocation.fiftyThreeFeet AS fiftyThreeFeet, "
			+ "allocation.allLengths AS allLengths, "
			+ "allocation.allotmentType AS allotmentType, "
			+ "allocation.totalIngatesAllowed AS totalIngatesAllowed, "
			+ "allocation.numberIngated AS numberIngated "
			+ "from EMSIngateAllocation as allocation "
			+ "where (allocation.ingateTerminalId like :ingateTerminalId or :ingateTerminalId is null) "
			+ "AND (allocation.onlineOriginStationTermId like :onlineOriginStationTermId or :onlineOriginStationTermId is null) "
			+ "AND (allocation.onlineDestinationStationTermId like :onlineDestinationStationTermId or :onlineDestinationStationTermId is null) "
			+ "AND (allocation.offlineDestinationStationTermId like :offlineDestinationStationTermId or :offlineDestinationStationTermId is null) "
			+ "AND (allocation.corporateCustomerId like :corporateCustomerId or :corporateCustomerId is null) "
			+ "AND (allocation.domestic in :#{#lineOfBusinesses} or :lineOfBusinesses is null) "
//			+ "AND (allocation.lineOfBusinesses in :#{#lineOfBusinesses.DOMESTIC}) "
//			+ "AND (allocation.lineOfBusinesses contains = lineOfBusinesses) "
			+ "AND (allocation.wayBillRoute like CONCAT('%',upper(:wayBillRoute),'%') or :wayBillRoute is null) "
//			+ "AND (allocation.trafficTypes contains :#{#trafficTypes}) "
			+ "AND (allocation.startDate like :startDate or :startDate is null) "
			+ "AND (allocation.endDate like :endDate or :endDate is null) ")
	Page<EMSIngateAllocation> searchAllIngateAllocations(Long ingateTerminalId, Long onlineOriginStationTermId,
			Long onlineDestinationStationTermId, Long offlineDestinationStationTermId, Long corporateCustomerId,
			List<LineOfBusiness> lineOfBusinesses,String wayBillRoute, Date startDate, Date endDate,
			Pageable pageable);

}
