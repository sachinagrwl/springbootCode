package com.nscorp.obis.services;

import com.nscorp.obis.domain.Station;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.sql.Date;


public interface StationService {

    Page<Station> searchStations(String stationName, String roadNumber, String FSAC, String state, String billAtFsac, String roadName, String operationStation, String splc,
								 String rule260Station, String intermodalIndicator, String char5Spell, String char5Alias, String char8Spell, String division, Date expirationDate,
								 Pageable pageable);

	Station updateStation(Station stationObj, String userId, String extensionSchema);


}
