package com.nscorp.obis.dto;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class PoolDTO {
	private Double poolId;
	private String poolName;
private String description;
	
	private String poolReservationType;
	
	private String truckerGroupCD;
	
	private String agreementRequired;
	private String checkTrucker;
	
	private String uVersion;
	
	private String createUserId;

	private String updateUserId;
	private Timestamp createDTM;
	
	private Timestamp updateDTM;
	
	private String updateExtentionSchema;

}
