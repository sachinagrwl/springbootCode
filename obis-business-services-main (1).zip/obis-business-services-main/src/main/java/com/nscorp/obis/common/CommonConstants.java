package com.nscorp.obis.common;

public class CommonConstants {
	
	 private CommonConstants() {
		    throw new IllegalStateException("Common Constant class");
		  }
	
	/* Header Constants */
	public static final String USER_ID = "userid";
	public static final String EXTENSION_SCHEMA = "extensionschema";

	public static final int GEN_TBL_MAX_SIZE = 8;
	public static final int GEN_TBL_MIN_SIZE = 1;
	public static final int GEN_CODE_SIZE_MAX_SIZE = 2;
	public static final int GEN_TBLDESC_MAX_SIZE = 20;
	public static final int	RESOURCE_NM_MAX_SIZE = 16;
	public static final int GEN_OWNR_GRP_MAX_SIZE = 8;
	public static final int GTN_CD_MIN_SIZE = 1;
	public static final int GTN_CD_MAX_SIZE = 10;
	public static final String EDI_RSN_TABLE = "EDI_RSN";
	public static final String INREJECT_TABLE = "INREJECT";
	public static final String INRTRJCT_TABLE = "INRTRJCT";
	public static final String LP_CFG_TABLE = "LP_CFG";


	public static final int U_VERSION_MAX_SIZE = 1;
	public static final int CREATE_USER_ID_MAX_SIZE = 8;
	public static final int CREATE_DT_TM_MAX_SIZE = 26;
	public static final int UPD_USER_ID_MAX_SIZE = 8;
	public static final int UPD_DT_TM_MAX_SIZE = 26;
	public static final int UPD_EXTN_SCHEMA_MAX_SIZE = 16;
	
	public static final int EQ_TYPE_MAX_SIZE = 1;
	public static final int EQ_TYPE_MIN_SIZE = 1;
	public static final int EQ_LENGTH_MAX_SIZE = 4;
	public static final int EQ_LENGTH_MIN_SIZE = 1;
	public static final int TARE_WEIGHT_MAX_SIZE = 6;
	
	public static final int GEN_TABLE_MAX_SIZE = 8;
	public static final int GEN_TABLE_MIN_SIZE = 1;
	public static final int GEN_TABLE_CODE_MAX_SIZE = 10;
	public static final int GEN_TABLE_CODE_MIN_SIZE = 1;
	public static final int GEN_SHORT_DESC_MAX_SIZE = 10;
	public static final int GEN_LONG_DESC_MAX_SIZE = 45;
	public static final int GEN_ADD_SHORT_MAX_SIZE = 10;
	public static final int GEN_ADD_LONG_MAX_SIZE = 45;
	public static final int GEN_FLAG_MAX_SIZE = 1;
	
	public static final int CAR_INIT_MAX_SIZE = 4;
	public static final int CAR_INIT_MIN_SIZE = 1;
	public static final int CAR_NR_LOW_MAX_SIZE = 6;
	public static final int CAR_NR_HIGH_MAX_SIZE = 6;
	public static final int CAR_EQ_TYPE_MAX_SIZE = 1;
	public static final int CAR_EQ_TYPE_MIN_SIZE = 1;
	public static final int AAR_TP_MIN_SIZE = 1;
	public static final int AAR_TP_MAX_SIZE = 4;
	public static final int CAR_OWNER_MIN_SIZE = 1;
	public static final int CAR_OWNER_MAX_SIZE = 4;
	public static final int C20_MAXWEIGHT_MAX_SIZE = 6;
	public static final int CAR_DESC_MAX_SIZE = 58;
	
	public static final int SHIPLINE_NUMBER_MIN_SIZE = 1;
	public static final int SHIPLINE_NUMBER_MAX_SIZE = 7;
	public static final int DESCRIPTION_MAX_SIZE = 35;
	
	public static final int CORP_CUST_MIN_SIZE = 1;
	public static final int CORP_CUST_MAX_SIZE = 15;
	public static final int CORP_LONG_NAME_MAX_SIZE = 30;
	public static final int CORP_SHORT_NAME_MAX_SIZE = 10;
	public static final int CUST_ID_MAX_SIZE = 15;
	public static final int ICGH_CD_MAX_SIZE = 4;
	public static final int PRIMARY_LOB_MAX_SIZE = 1;
	public static final int SECONDARY_LOB_MAX_SIZE = 10;
	public static final int SCAC_MAX_SIZE = 4;
	public static final int TERMINAL_FEED_ENABLED_MAX_SIZE = 1;
	public static final int ACCOUNT_MANAGER_MAX_SIZE = 30;
	
	public static final int CAR_TYPE_MIN_SIZE = 1;
	public static final int CAR_TYPE_MAX_SIZE = 4;
	public static final int FREIGHT_TYPE_MIN_SIZE = 1;
	public static final int FREIGHT_TYPE_MAX_SIZE = 4;

	public static final int AAR_TYPE_MIN_SIZE = 1;
	public static final int AAR_TYPE_MAX_SIZE = 4;
	public static final int AAR_DESC_TYPE_MAX_SIZE = 30;
	public static final int AAR_CAPACITY_MAX_SIZE = 5;
	public static final int IM_DESC_TYPE_MAX_SIZE = 30;
	public static final int STANDARD_AAR_TYPE_MAX_SIZE = 1;

	public static final int TERM_ID_MIN_SIZE = 1;
	public static final int TERM_ID_MAX_SIZE = 15;
	public static final int ROAD_NUMBER_MAX_SIZE = 4;
	public static final int FSAC_MAX_SIZE = 6;
	public static final int STATION_NAME_MAX_SIZE = 19;
	public static final int STATE_MAX_SIZE = 2;
	public static final int BILL_AT_FSAC_MAX_SIZE = 6;
	public static final int ROAD_NAME_MAX_SIZE = 4;
	public static final int OP_STN_MAX_SIZE = 5;
	public static final int SPLC_MAX_SIZE = 9;
	public static final int RULE_260_STN_MAX_SIZE = 5;
	public static final int INTERMODAL_IND_MAX_SIZE = 1;
	public static final int OP_STA_5_SPELL_MAX_SIZE = 5;
	public static final int OP_STA_ALIAS_MAX_SIZE = 5;
	public static final int OP_STN_8_SPELL_MAX_SIZE = 8;
	public static final int DIV_CD_MAX_SIZE = 2;
	public static final int STN_EXP_DATE_MAX_SIZE = 10;
	public static final int BILLING_IND_MAX_SIZE = 1;
	public static final int EXPIRED_DT_MAX_SIZE = 26;
	public static final int TOP_PICK_MAX_SIZE = 1;
	public static final int BOTTOM_PICK_MAX_SIZE = 1;
	
	/* EMS Ingate Restrictions */
	public static final int RESTRICT_ID_MIN_SIZE = 1;
	public static final long NON_TERMINAL_SPECIFIC = 99999999999999L;
	public static final int RESTRICT_ID_MAX_SIZE = 15;
	public static final int INGT_TERM_MIN_SIZE = 1;
	public static final int INGT_TERM_MAX_SIZE = 15;
	public static final int ONL_ORIG_MAX_SIZE = 15;
	public static final int ONL_DEST_MAX_SIZE = 15;
	public static final int OFFL_DEST_MAX_SIZE = 15;
	public static final int EQ_INIT_MAX_SIZE = 4;
	public static final int EQ_LOW_NR_MAX_SIZE = 6;
	public static final int EQ_HIGH_NR_MAX_SIZE = 6;
	public static final int CORP_CUST_ID_MAX_SIZE = 15;
	public static final int PRIMARY_LOB_EMS_MAX_SIZE = 1;
	public static final int EQ_TP_MAX_SIZE = 1;
	public static final int LOAD_EMPTY_CD_MAX_SIZE = 1;
	public static final int EQ_LGTH_MAX_SIZE = 10;
	public static final int GROSS_WEIGHT_MAX_SIZE = 10;
	public static final int WB_ROUTE_MAX_SIZE = 110;
	public static final int HAZ_IND_MAX_SIZE = 1;
	public static final int WT_QUAL_MAX_SIZE = 2;
	public static final int ACTIVE_MAX_SIZE = 1;
	public static final int ST_DATE_MAX_SIZE = 10;
	public static final int ST_TIME_MAX_SIZE = 8;
	public static final int END_DATE_MAX_SIZE = 10;
	public static final int END_TIME_MAX_SIZE = 8;
	public static final int CREATE_EXTN_SCHEMA_MAX_SIZE = 32;
	public static final int EMS_UPD_EXTN_SCHEMA_MAX_SIZE = 32;
	public static final int IS_REEFER_MAX_SIZE = 1;
	public static final int TEMP_IND_MAX_SIZE = 1;
	public static final int ONL_ORIG_MIN_SIZE = 1;
	public static final int EQ_HIGH_NR_MIN_SIZE = 1;
	public static final int EQ_LOW_NR_MIN_SIZE = 1;
	public static final int EQ_LGTH_MIN_SIZE = 1;
	public static final int GROSS_WEIGHT_MIN_SIZE = 1;
	public static final int TERM_TBL_MIN_SIZE = 1;
	public static final int TERM_TBL_MAX_SIZE = 15;
	public static final int BLK_TBL_MIN_SIZE = 01;
	public static final int BLK_TBL_MAX_SIZE = 99;
}
