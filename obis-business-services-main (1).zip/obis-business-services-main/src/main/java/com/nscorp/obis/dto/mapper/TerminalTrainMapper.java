package com.nscorp.obis.dto.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.nscorp.obis.domain.TerminalTrain;
import com.nscorp.obis.dto.TerminalTrainDTO;

@Mapper(componentModel = "spring")
public interface TerminalTrainMapper {

	TerminalTrainMapper INSTANCE = Mappers.getMapper(TerminalTrainMapper.class);

	TerminalTrainDTO terminalTrainToTerminalTrainDTO(TerminalTrain terminalTrain);

	TerminalTrain terminalTrainDTOToTerminalTrain(TerminalTrainDTO terminalTrainDTO);
}
