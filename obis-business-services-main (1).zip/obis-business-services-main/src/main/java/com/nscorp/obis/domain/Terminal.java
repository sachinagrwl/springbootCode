package com.nscorp.obis.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="TERMINAL")
public class Terminal {
	@Id
	@Column(name="TERM_ID", length = 15, columnDefinition = "Double", nullable=false)
    Long terminalId;
	
	@Column(name = "TERM_NM", columnDefinition = "char(30)", nullable = true)
	private String terminalName;

	@Column(name = "STN_XRF_ID", columnDefinition = "Double", nullable = true)
	private Long stnXrfId;


	public Date getExpiredDate() {
		return expiredDate;
	}

	public void setExpiredDate(Date expiredDate) {
		this.expiredDate = expiredDate;
	}

	@Column(name = "EXPIRED_DT", columnDefinition = "Date", nullable = true)
	private Date expiredDate;

	public Long getStnXrfId() {
		if(stnXrfId != null)
			return stnXrfId;
		else
			return null;
	}

	public void setStnXrfId(Long stnXrfId) {
		this.stnXrfId = stnXrfId;
	}

//	@OneToMany(mappedBy = "terminal", fetch = FetchType.LAZY)
//    private List<EMSIngateRestriction> emsIngateRestriction = new ArrayList<>();

	public Long getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(Long terminalId) {
		this.terminalId = terminalId;
	}

	public String getTerminalName() {
		if(terminalName != null) {
			return terminalName.trim();
		} else {
			return terminalName;
		}
	}

	public void setTerminalName(String terminalName) {
		this.terminalName = terminalName;
	}

	public Terminal(Long terminalId, String terminalName, Long stnXrfId, Date expiredDate) {
		super();
		this.terminalId = terminalId;
		this.terminalName = terminalName;
		this.stnXrfId = stnXrfId;
		this.expiredDate = expiredDate;
	}

	public Terminal() {
		super();
	}
	
}
