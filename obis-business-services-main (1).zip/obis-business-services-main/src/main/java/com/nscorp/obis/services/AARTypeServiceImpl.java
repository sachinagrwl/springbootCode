package com.nscorp.obis.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nscorp.obis.domain.AARType;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.repository.AARTypeRepository;

@Service
@Transactional
public class AARTypeServiceImpl implements AARTypeService {
	
	@Autowired
	private AARTypeRepository aarTypeRepo;
	
	private static final Logger logger = LoggerFactory.getLogger(AARTypeServiceImpl.class);
	
	@Override
	public List<AARType> getAllAARTypes(String type) {
		List<String> search = new ArrayList<String>();
		List<AARType> aarTypeList = new ArrayList<AARType>();
		List<AARType> list = new ArrayList<AARType>();
		logger.info("Type - {}", type);
		if(type.equals("car")) {
			logger.info("Type - {}", type);
			search.add("P");
			search.add("Q");
			search.add("S");
			for(String var : search) {
				aarTypeList = aarTypeRepo.findByAarTypeStartsWith(var);
				list.addAll(aarTypeList);
			}
		}
		else if(type.equals("freight")) {
			logger.info("Type - {}", type);
			search.add("U");
			search.add("Z");
			for(String var : search) {
				aarTypeList = aarTypeRepo.findByAarTypeStartsWith(var);
				list.addAll(aarTypeList);
			}
		}
		if(list.isEmpty()) {
			throw new NoRecordsFoundException("No Records found for AAR Type!");
		}
		return list;
	}

}
