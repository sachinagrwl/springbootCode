package com.nscorp.obis.domain;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Entity
@Table(name = "TEMP_RESTRICT")
public class EMSIngateRestriction extends BaseEMSIngateRestriction {

	@Id
	@Column(name = "RESTRICT_ID", length = 15, columnDefinition = "double", nullable = false)
	public Long restrictId;

	@Column(name = "PRIMARY_LOB", columnDefinition = "char(1)", nullable = true)
	private String primaryLineOfBusiness;

	@Column(name = "EQ_TP", columnDefinition = "char(1)", nullable = true)
	private String equipmentType;

	public String getPrimaryLineOfBusiness() {
		if (primaryLineOfBusiness != null) {
			return primaryLineOfBusiness.trim();
		} else {
			return primaryLineOfBusiness;
		}
	}

	public void setPrimaryLineOfBusiness(String primaryLineOfBusiness) {
		if (primaryLineOfBusiness != null) {
			this.primaryLineOfBusiness = primaryLineOfBusiness.toUpperCase();
		} else {
			this.primaryLineOfBusiness = primaryLineOfBusiness;
		}
	}

	public String getEquipmentType() {
		if (equipmentType != null) {
			return equipmentType.trim();
		} else {
			return equipmentType;
		}
	}

	public void setEquipmentType(String equipmentType) {
		if (equipmentType != null) {
			this.equipmentType = equipmentType.toUpperCase();
		} else {
			this.equipmentType = equipmentType;
		}
	}

	public Long getRestrictId() {
		return restrictId;
	}

	public void setRestrictId(Long restrictId) {
		this.restrictId = restrictId;
	}

	public EMSIngateRestriction() {
	}

	public EMSIngateRestriction(String uversion, String createUserId, Timestamp createDateTime, String updateUserId,
			Timestamp updateDateTime, String updateExtensionSchema, Long restrictId, String primaryLineOfBusiness,
			String equipmentType, Terminal ingateTerminal, Station onlineOriginStation,
			Station onlineDestinationStation, Station offlineDestinationStation, String equipmentInit,
			Integer equipmentLowestNumber, Integer equipmentHighestNumber, CorporateCustomer corporateCustomer,
			String container, String trailer, String chassis, List<EquipmentType> equipmentTypes, String loadEmptyCode,
			Integer equipmentLength, Integer grossWeight, String wayBillRoute, Boolean hazardousIndicator,
			String active, LocalDate startDate, LocalTime startTime, LocalDate endDate, LocalTime endTime,
			String createExtensionSchema, Boolean reeferIndicator, String temperoryIndicator, String allLengths) {
		super(uversion, createUserId, createDateTime, updateUserId, updateDateTime, updateExtensionSchema,
				ingateTerminal, onlineOriginStation, onlineDestinationStation, offlineDestinationStation, equipmentInit,
				equipmentLowestNumber, equipmentHighestNumber, corporateCustomer, container, trailer, chassis,
				equipmentTypes, loadEmptyCode, equipmentLength, grossWeight, wayBillRoute, hazardousIndicator, active,
				startDate, startTime, endDate, endTime, createExtensionSchema, reeferIndicator, temperoryIndicator,
				allLengths);
		this.restrictId = restrictId;
		this.primaryLineOfBusiness = primaryLineOfBusiness;
		this.equipmentType = equipmentType;
	}
}