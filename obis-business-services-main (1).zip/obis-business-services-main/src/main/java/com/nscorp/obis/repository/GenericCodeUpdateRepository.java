package com.nscorp.obis.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.nscorp.obis.domain.GenericCodeUpdate;

public interface GenericCodeUpdateRepository extends JpaRepository <GenericCodeUpdate,String> {

	List<GenericCodeUpdate> findByGenericTable(String tableName);
	
    List<GenericCodeUpdate> findByGenericTableIgnoreCase(String tableName);

	GenericCodeUpdate findByGenericTableAndGenericTableCodeIgnoreCase(String genericTable, String genericTableCode);

	GenericCodeUpdate findByGenericTableAndGenericTableCode(String genericTable, String genericTableCode);
	
	boolean existsByGenericTableAndGenericTableCodeIgnoreCase(String genericTable, String genericTableCode);
	
	void deleteByGenericTableAndGenericTableCodeIgnoreCase(String genericTable, String genericTableCode);
	
	boolean existsByGenericTableIgnoreCase(String genericTable);

	boolean existsByGenericTableAndGenericTableCode(String genericTable, String genericTableCode);
	
	void deleteByGenericTableAndGenericTableCode(String genericTable, String genericTableCode);
	
	boolean existsByGenericTable(String genericTable);
}
