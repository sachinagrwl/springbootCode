package com.nscorp.obis.services;

import com.nscorp.obis.domain.EMSIngateRestriction;

import java.util.List;

public interface EMSIngateRestrictionService {

    List<EMSIngateRestriction> getAllRestrictions();

	EMSIngateRestriction insertRestriction(EMSIngateRestriction restrictionObj, String userId, String extensionSchema);

	EMSIngateRestriction updateRestriction(EMSIngateRestriction restrictionObj, String userId, String extensionSchema);
}
