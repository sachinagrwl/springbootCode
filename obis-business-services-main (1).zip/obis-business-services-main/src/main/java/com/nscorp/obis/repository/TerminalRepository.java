package com.nscorp.obis.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nscorp.obis.domain.Terminal;

@Repository
public interface TerminalRepository extends JpaRepository<Terminal,Long>{

	boolean existsByTerminalId(Long terminalId);

	List<Terminal> findAllByOrderByTerminalNameAsc();

	@Query("SELECT terminal.stnXrfId from Terminal terminal where terminal.terminalId = :terminalId AND terminal.expiredDate is null")
	Long getStationXrfId(Long terminalId);

	boolean existsByTerminalIdAndExpiredDateIsNull(Long terminalId);

	@Query(value = "SELECT new com.nscorp.obis.domain.Terminal(terminal.terminalId, "+
	"terminal.terminalName, terminal.stnXrfId, terminal.expiredDate) from Terminal terminal where (terminal.expiredDate is null) "
	+ "order by terminal.terminalName")
	List<Terminal> fetchAllActiveTerminals();

}
