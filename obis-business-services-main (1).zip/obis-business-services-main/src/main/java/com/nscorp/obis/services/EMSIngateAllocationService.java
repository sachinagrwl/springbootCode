package com.nscorp.obis.services;

import java.sql.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.nscorp.obis.domain.EMSIngateAllocation;
import com.nscorp.obis.domain.LineOfBusiness;

public interface EMSIngateAllocationService {
	Page<EMSIngateAllocation> searchIngateAllocation(Long ingateTerminalId, Long onlineOriginStationTermId,
			Long onlineDestinationStationTermId, Long offlineDestinationStationTermId, Long corporateCustomerId,
			List<LineOfBusiness> lineOfBusinesses, String wayBillRoute, Date startDate, Date endDate,
			Pageable pageable);
}
