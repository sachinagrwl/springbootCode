package com.nscorp.obis.services;

import com.nscorp.obis.domain.Block;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

public interface BlockService {
	public List<Block> getAllBlocks( Double termId, String trainNr );
	Block updateBlock(@Valid Block blockObj, Map<String ,String> headers);
}
