package com.nscorp.obis.repository;

import org.springframework.stereotype.Repository;

import com.nscorp.obis.domain.DestinationTerminalNotifyProfile;
import java.util.List;

import javax.validation.Valid;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface DestinationTerminalNotifyProfileRepository extends JpaRepository<DestinationTerminalNotifyProfile,Double>{

	List<DestinationTerminalNotifyProfile> findByTerminalId(@Valid Long termId);
	
	DestinationTerminalNotifyProfile findByNotifyProfileId(@Valid Long profileId);

	boolean existsByNotifyProfileId(@Valid Long profileId);
	void deleteByNotifyProfileId(Long notifyProfileId);


}
