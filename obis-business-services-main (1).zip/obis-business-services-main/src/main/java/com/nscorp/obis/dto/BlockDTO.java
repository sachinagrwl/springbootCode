package com.nscorp.obis.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import org.springframework.data.annotation.ReadOnlyProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class BlockDTO extends AuditInfoDTO{
	private Double termId;
	private String trainNr;
	private Double blockId;
	
	@NotBlank(message="Block Name Should not be empty")
	@Size(min=1, max=15, message = "Block Name should not be more than 15")
	private String blockNm;
	private Double parantBlockId;
	
	@NotBlank(message="Block Order Should not be empty")
	@Range(min=01, max=99, message="Block Order should be between 1 to 99")
	@Schema(required = false,description="This tells the Order of the Block" )
	private String blockOrder;
	
	@Range(min=1, max=9,message="Block Priority should be between 1 to 9") 
	@Schema(required = false,description="This tells the Priority" )
	private Integer blockPriority;
	
	@ReadOnlyProperty()
	private String swInterchange;
	
	@Schema(required = false,description="Type 'Y'-Yes and 'N'-No")
	@Pattern(regexp="^(Y|N)$",message="Only Y and N is allowed")
	private String allowSameCar;
	
	@Pattern(regexp="^(Y|N)$",message="Only Y and N is allowed")
	private String blockMon;
	
	@Pattern(regexp="^(Y|N)$",message="Only Y and N is allowed")
	private String blockTue;
	
	@Pattern(regexp="^(Y|N)$",message="Only Y and N is allowed")
	private String blockWed;
	
	@Pattern(regexp="^(Y|N)$",message="Only Y and N is allowed")
	private String blockThu;
	
	@Pattern(regexp="^(Y|N)$",message="Only Y and N is allowed")
	private String blockFri;
	
	@Pattern(regexp="^(Y|N)$",message="Only Y and N is allowed")
	private String blockSat;
	
	@Pattern(regexp="^(Y|N)$",message="Only Y and N is allowed")
	private String blockSun;

	@Schema(required = false,description="Defines the height Feet")
	private Integer hightFeet;
	
	@Schema(required = false,description="Defines the height Inches")
	private Integer hightInches;
	
	@ReadOnlyProperty
	private Integer weight;
}
