package com.nscorp.obis.domain;

public enum TrafficType {

	STEEL_WHEEL, RUBBER_TIRE, LOCAL
}
