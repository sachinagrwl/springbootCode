package com.nscorp.obis.services;

import com.nscorp.obis.common.CommonConstants;
import com.nscorp.obis.domain.EMSEquipmentLengthRestriction;
import com.nscorp.obis.domain.EMSIngateRestriction;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.exception.RecordNotAddedException;
import com.nscorp.obis.repository.CorporateCustomerRepository;
import com.nscorp.obis.repository.EMSIngateRestrictionRepository;
import com.nscorp.obis.repository.StationRepository;
import com.nscorp.obis.repository.TerminalRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.validation.Valid;
import java.util.List;

@Service
@Transactional
public class EMSIngateRestrictionServiceImpl implements EMSIngateRestrictionService {

    @Autowired
	EMSIngateRestrictionRepository emsIngateRestrictionRepository;

    @Autowired
    TerminalRepository terminalRepository;
    
    @Autowired
    StationRepository stationRepository;
    
    @Autowired
    CorporateCustomerRepository corporateCustomerRepository;
    
    private void emsRestrictionValidations(EMSIngateRestriction restrictionObj) {
    	
    	// Check Ingate terminal is valid or not
    	if(restrictionObj.getIngateTerminalId() != null && !terminalRepository.existsByTerminalIdAndExpiredDateIsNull((Long) restrictionObj.getIngateTerminalId())) {
			throw new NoRecordsFoundException("Ingate Terminal with Id "+restrictionObj.getIngateTerminalId()+" not found!");
		}

        //Auto populate online origin using STN_XRF ID
        if(restrictionObj.getIngateTerminalId() != null && restrictionObj.getIngateTerminalId() != 99999999999999L){
            Long originStationId = terminalRepository.getStationXrfId(restrictionObj.getIngateTerminalId());

            if(restrictionObj.getOnlineOriginStationTermId() == null) {
                restrictionObj.setOnlineOriginStationTermId(originStationId);
            }
            else if(!originStationId.equals(restrictionObj.getOnlineOriginStationTermId())){
                throw new RecordNotAddedException("Online Origin station Id " + restrictionObj.getOnlineOriginStationTermId() + " is either not valid or not found in 'Terminal' table!");
            }
        }

        //Check for Non-terminal
        if(restrictionObj.getIngateTerminalId() == CommonConstants.NON_TERMINAL_SPECIFIC) {
            if(restrictionObj.getOnlineOriginStationTermId() == null) {
                restrictionObj.setOnlineOriginStationTermId(null);
            }
            else {
                throw new RecordNotAddedException("Online Origin Station Id should be null for Non-Terminal specific EMS Ingate Restriction!");
            }
        }

      //Check Online destination and offline destinations are valid or not; STATION_XRF where expired date is null
		if(restrictionObj.getOnlineDestinationStationTermId() != null && !stationRepository.existsByTermIdAndExpiredDateIsNull(restrictionObj.getOnlineDestinationStationTermId())) {
			throw new NoRecordsFoundException("Online Destination Station with Id "+restrictionObj.getOnlineDestinationStationTermId()+" not found!");
		}

		if(restrictionObj.getOfflineDestinationStationTermId() != null && !stationRepository.existsByTermIdAndExpiredDateIsNull(restrictionObj.getOfflineDestinationStationTermId())) {
			throw new NoRecordsFoundException("Offline Destination Station with Id "+restrictionObj.getOfflineDestinationStationTermId()+" not found!");
		}

		//Check Corporate customerId is valid or not
		if(restrictionObj.getCorporateCustomerId() != null && !corporateCustomerRepository.existsById(restrictionObj.getCorporateCustomerId())) {
			throw new NoRecordsFoundException("Corporate Customer Id : "+restrictionObj.getCorporateCustomerId()+" not found!");
		}

		// Both fields are required at a time
		if(restrictionObj.getCorporateCustomerId() == null && restrictionObj.getLineOfBusinesses().isEmpty()) {
				throw new RecordNotAddedException("A 'Corporate Shipper(Customer)' or a 'Primary Line Of Business' value is required!");
		}
		if(restrictionObj.getWayBillRoute() == null && restrictionObj.getTrafficTypes().isEmpty()) {
				throw new RecordNotAddedException("A 'Way Bill Route' or a 'Traffic Type' value is required!");
		}

		//Active field is required
		if(!(restrictionObj.getActive().equalsIgnoreCase("T"))
				&& !(restrictionObj.getActive().equalsIgnoreCase("F"))) {
			throw new RecordNotAddedException("'active' value must be either 'T' or 'F'");
		}

		//TemporaryIndicator fields is required
		if(!(restrictionObj.getTemperoryIndicator().equalsIgnoreCase("T"))
				&& !(restrictionObj.getTemperoryIndicator().equalsIgnoreCase("F"))) {
			throw new RecordNotAddedException("'temporaryIndicator' value must be either 'T' or 'F'");
		}

		//Load Empty code is required and values must be L,E or B
		if(!(restrictionObj.getLoadEmptyCode().equalsIgnoreCase("L"))
				&& !(restrictionObj.getLoadEmptyCode().equalsIgnoreCase("E")) && !(restrictionObj.getLoadEmptyCode().equalsIgnoreCase("B"))) {
			throw new RecordNotAddedException("'loadEmptyCode' value must be 'L', 'E' or 'B'");
		}

		//Equipment length should be '240', '336', '480', '540', '576', '636' or null
		if(restrictionObj.getEquipmentLength() != null) {
			if(restrictionObj.getEquipmentLength() != 240
					&& restrictionObj.getEquipmentLength() != 336 && restrictionObj.getEquipmentLength() != 480
					&& restrictionObj.getEquipmentLength() != 540 && restrictionObj.getEquipmentLength() != 576
					&& restrictionObj.getEquipmentLength() != 636) {
				throw new RecordNotAddedException("'equipmentLength' value must be '240', '336', '480', '540', '576', '636' or null");
			}
		}

		//HazardousIndicator value should be null or 0 or 1
		if(restrictionObj.getHazardousIndicator() != null) {
			if(!(restrictionObj.getHazardousIndicator().equals(true))
					&& !(restrictionObj.getHazardousIndicator().equals(false))) {
				throw new RecordNotAddedException("'hazardousIndicator' value must be either 'true', 'false' or null");
			}
		}

		//Reefer Indicator must be 0,1 or null
		if(restrictionObj.getReeferIndicator() != null) {
			if(!(restrictionObj.getReeferIndicator().equals(true))
					&& !(restrictionObj.getReeferIndicator().equals(false))) {
				throw new RecordNotAddedException("'reeferIndicator' value must be either 'true', 'false' or null");
			}
		}
    	
		//Check whether any one Equipment Type & Length value is given
		if(restrictionObj.getEquipmentTypes().isEmpty()) {
			throw new RecordNotAddedException("Any One Equipment Type value should be provided!");
		}
		if(restrictionObj.getEmsEquipmentLengthRestrictions().isEmpty()) {
			throw new RecordNotAddedException("Any One Equipment Length value should be provided!");
		}

		//Either RESTRICT_ALL or ANY size
		if(restrictionObj.getEmsEquipmentLengthRestrictions().size() > 1 && restrictionObj.getEmsEquipmentLengthRestrictions().contains(EMSEquipmentLengthRestriction.RESTRICT_ALL)){
			throw new RecordNotAddedException("EMS Length Restrictions field requires either 'RESTRICT_ALL' or Size");
		}
		
    }

    @Override
    public List<EMSIngateRestriction> getAllRestrictions() {
        List<EMSIngateRestriction> emsIngateRestrictions = emsIngateRestrictionRepository.findAll();

        if(emsIngateRestrictions.isEmpty())
            throw new NoRecordsFoundException("No Records are found for EMS Ingate Restrictions");

        return emsIngateRestrictions;
    }

	@Override
	public EMSIngateRestriction insertRestriction(EMSIngateRestriction restrictionObj, String userId,
												  String extensionSchema) {

		Long generatedRestrictId = emsIngateRestrictionRepository.SGK();
		restrictionObj.setRestrictId(generatedRestrictId);

		if(extensionSchema != null) {
			extensionSchema = extensionSchema.toUpperCase();
		} else {
			throw new NullPointerException("Extension Schema should not be null, empty or blank");
		}
		
		//Validating each fields
		emsRestrictionValidations(restrictionObj);
		
		restrictionObj.setCreateUserId(userId.toUpperCase());
		restrictionObj.setUpdateUserId(userId.toUpperCase());
		restrictionObj.setCreateExtensionSchema(extensionSchema);
		restrictionObj.setUpdateExtensionSchema(extensionSchema);
		restrictionObj.setUversion("!");

		if(restrictionObj.getIngateTerminalId() != null && restrictionObj.getStartTime() != null
				&& restrictionObj.getEndTime() != null && !(restrictionObj.getEmsEquipmentLengthRestrictions().isEmpty())
				&& !(restrictionObj.getEquipmentTypes().isEmpty())) {
			emsIngateRestrictionRepository.save(restrictionObj);
		} else {
			throw new RecordNotAddedException("'Ingate Terminal, Start Date, End Date, Equipment Type & Equipment Length' "
					+ "values should be present!");
		}

		EMSIngateRestriction restriction = emsIngateRestrictionRepository.findByRestrictId(restrictionObj.getRestrictId());
		return restriction;
	}

	@Override
	public EMSIngateRestriction updateRestriction(@Valid EMSIngateRestriction restrictionObj, String userId, String extensionSchema) {

    	//Check RestrictId is not null
		if(restrictionObj.getRestrictId() == null)
			throw new NoRecordsFoundException("Restrict Id is mandatory Field");

    	//Check RestrictId is available or not
    	if(!emsIngateRestrictionRepository.existsById(restrictionObj.getRestrictId())) {
			throw new NoRecordsFoundException("No record found under this search!");
		}
    	
    	//Validating each fields
    	emsRestrictionValidations(restrictionObj);

		//Check Extension Schema is not null
		if(extensionSchema != null) {
			extensionSchema = extensionSchema.toUpperCase();
		} else {
			throw new NullPointerException("Extension Schema should not be null, empty or blank");
		}

		//AuditInfo Required Fields
		restrictionObj.setCreateUserId(userId.toUpperCase());
		restrictionObj.setUpdateUserId(userId.toUpperCase());
		restrictionObj.setCreateExtensionSchema(extensionSchema);
		restrictionObj.setUpdateExtensionSchema(extensionSchema);
		restrictionObj.setUversion("!");

		//Create Date is throwing an error, So setting the Date from repository 
		EMSIngateRestriction emsIngateRestriction = emsIngateRestrictionRepository.findByRestrictId(restrictionObj.getRestrictId());
		restrictionObj.setCreateDateTime(emsIngateRestriction.getCreateDateTime());
		
		//Check all required fields are there
		if(restrictionObj.getIngateTerminalId() != null && restrictionObj.getStartTime() != null
				&& restrictionObj.getEndTime() != null && !(restrictionObj.getEmsEquipmentLengthRestrictions().isEmpty())
				&& !(restrictionObj.getEquipmentTypes().isEmpty())) {
			emsIngateRestrictionRepository.save(restrictionObj);
		} else {
			throw new RecordNotAddedException("'Ingate Terminal, Start Date, End Date, Equipment Type & Equipment Length' "
					+ "values should be present!");
		}

		emsIngateRestriction = emsIngateRestrictionRepository.findByRestrictId(restrictionObj.getRestrictId());
		return emsIngateRestriction;
	}

}
