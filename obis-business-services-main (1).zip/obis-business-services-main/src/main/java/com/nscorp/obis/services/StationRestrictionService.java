package com.nscorp.obis.services;

import java.util.List;
import javax.validation.Valid;
import com.nscorp.obis.domain.StationRestriction;

public interface StationRestrictionService {

	List<StationRestriction> getStationRestriction(Long termId);

	void deleteStationRestriction(Long termId, @Valid StationRestriction stationRestrictionsObj);

	StationRestriction addStationRestriction(Long termId, StationRestriction stationRestrictions, String userId,
			String extensionSchema);

}
