package com.nscorp.obis.services;

import java.sql.Date;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.nscorp.obis.domain.EMSIngateAllocation;
import com.nscorp.obis.domain.LineOfBusiness;
import com.nscorp.obis.domain.TrafficType;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.exception.SizeExceedException;
import com.nscorp.obis.repository.EMSIngateAllocationRepository;

@Service
@Transactional
public class EMSIngateAllocationServiceImpl implements EMSIngateAllocationService {

//	@Autowired
//	EMSIngateAllocationRepository emsIngateAllocationRepository;
//
	@Override
	public Page<EMSIngateAllocation> searchIngateAllocation(Long ingateTerminalId, Long onlineOriginStationTermId,
			Long onlineDestinationStationTermId, Long offlineDestinationStationTermId, Long corporateCustomerId,
			List<LineOfBusiness> lineOfBusinesses, String wayBillRoute, Date startDate, Date endDate,
			Pageable pageable) {
//		Page<EMSIngateAllocation> searchIngateAllocationsPage = emsIngateAllocationRepository.searchAllIngateAllocations(ingateTerminalId,
//				onlineOriginStationTermId, onlineDestinationStationTermId, offlineDestinationStationTermId, corporateCustomerId,
//				lineOfBusinesses, wayBillRoute, startDate, endDate, pageable);
////		if (searchIngateAllocationsPage.getTotalPages() == 0)
////			throw new NoRecordsFoundException("No records matches this search");
//		System.out.println(searchIngateAllocationsPage.getContent());
////		System.out.println(searchIngateAllocationsPage.stream().);
//
//		if (searchIngateAllocationsPage.getPageable().getPageNumber() >= searchIngateAllocationsPage.getTotalPages())
//			throw new SizeExceedException(
//					"Page Number must be less than or equal to " + searchIngateAllocationsPage.getTotalPages());
//
		return null;
	}

}
