package com.nscorp.obis.controller;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nscorp.obis.common.ControllerConstants;
import com.nscorp.obis.domain.Terminal;
import com.nscorp.obis.dto.TerminalDTO;
import com.nscorp.obis.dto.mapper.TerminalMapper;
import com.nscorp.obis.exception.NoRecordsFoundException;
import com.nscorp.obis.response.APIResponse;
import com.nscorp.obis.response.ResponseStatusCode;
import com.nscorp.obis.services.TerminalService;

@RestController
@RequestMapping("/")
public class TerminalController {
	
	@Autowired
	TerminalService terminalService;
		
//	private static final Logger logger = LoggerFactory.getLogger(CodeTableSelectionController.class);
	
	@GetMapping(value= ControllerConstants.TERMINAL)
	public ResponseEntity<APIResponse<List<TerminalDTO>>> getAllTerminals(){
		
		try {
			List<TerminalDTO> terminalDtoList = Collections.emptyList();
			List<Terminal> terminalList = terminalService.getAllTerminals();
			if (terminalList != null && !terminalList.isEmpty()) {
				terminalDtoList = terminalList.stream()
						.map(TerminalMapper.INSTANCE::terminalToTerminalDTO)
						.collect(Collectors.toList());
			}
			APIResponse<List<TerminalDTO>> responseObj = new APIResponse<>(Arrays.asList("Successfully retrieved data!"),terminalDtoList, ResponseStatusCode.SUCCESS);
			return ResponseEntity.status(HttpStatus.OK).body(responseObj);
		} catch (NoRecordsFoundException e){
			APIResponse<List<TerminalDTO>> responseObj = new APIResponse<>(Arrays.asList(e.getMessage()), ResponseStatusCode.INFORMATION);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseObj);
		} catch (Exception e){
			APIResponse<List<TerminalDTO>> responseObj = new APIResponse<>(Arrays.asList(e.getMessage()), ResponseStatusCode.FAILURE);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseObj);
		}
	
	}

}
