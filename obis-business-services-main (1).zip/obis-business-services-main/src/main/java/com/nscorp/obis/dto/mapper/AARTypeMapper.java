package com.nscorp.obis.dto.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.nscorp.obis.domain.AARType;
import com.nscorp.obis.dto.AARTypeDTO;

@Mapper(componentModel = "spring")
public interface AARTypeMapper {

	AARTypeMapper INSTANCE = Mappers.getMapper(AARTypeMapper.class);

	AARTypeDTO aarTypeToAARTypeDTO(AARType aarType);

	AARType aarTypeDTOToAARType(AARTypeDTO aarTypeDTO);
	
}
