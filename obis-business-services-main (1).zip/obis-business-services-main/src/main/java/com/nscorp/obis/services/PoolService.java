package com.nscorp.obis.services;

import java.util.List;
import java.util.Map;

import com.nscorp.obis.domain.Pool;

public interface PoolService {

	Pool insertPool(Pool pool, Map<String, String> headers);

	List<Pool> getPools();

}
