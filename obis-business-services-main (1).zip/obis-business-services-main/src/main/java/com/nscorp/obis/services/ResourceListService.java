package com.nscorp.obis.services;

import java.util.List;

import com.nscorp.obis.domain.ResourceList;

public interface ResourceListService {

	List<ResourceList> getAllResourceList();

}
