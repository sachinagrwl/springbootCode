package com.nscorp.obis.domain;

import java.io.Serializable;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class TermTrainComposite implements Serializable {
	
	 private long termId;
     private String trainNr;

	 public TermTrainComposite() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TermTrainComposite(long termId ,String trainNr) {
		super();
		this.termId = termId;
		this.trainNr =trainNr;
	}

}
