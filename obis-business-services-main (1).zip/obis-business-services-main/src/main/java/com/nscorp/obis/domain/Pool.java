package com.nscorp.obis.domain;


import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;


@Entity
public class Pool {
public Pool(Double poolId, String poolName, String description, String agreementRequired, String checkTrucker,
			String uVersion, String createUserId, String updateUserId, Timestamp createDTM, Timestamp updateDTM,
			String updateExtentionSchema) {
		super();
		this.poolId = poolId;
		this.poolName = poolName;
		this.description = description;
		this.agreementRequired = agreementRequired;
		this.checkTrucker = checkTrucker;
		this.uVersion = uVersion;
		this.createUserId = createUserId;
		this.updateUserId = updateUserId;
		this.createDTM = createDTM;
		this.updateDTM = updateDTM;
		this.updateExtentionSchema = updateExtentionSchema;
	}
//    @Id
//	@GeneratedValue(strategy=GenerationType.SEQUENCE)
    @Id
	@Column(name="POOL_ID", length = 53, columnDefinition = "Double", nullable=false)
	private Double poolId;
    @Column(name="POOL_NM", columnDefinition="char(10)", nullable=false)
	private String poolName;
//	@Column(name = "POOL_TYPE")
//	private String poolType;S
	//private String name;
	@Column(name="POOL_DESC", columnDefinition="char(30)", nullable=false)
	private String description;
	
//	@OneToOne(cascade=CascadeType.ALL)
//	@JoinColumn(name="poolTypeId")
//	private PoolType reservationType;
	@Column(name="POOL_RSRV_TP", columnDefinition="char(2)")
	private String poolReservationType;
	@Column(name="TKR_GRP_CD", columnDefinition="char(10)")
	private String truckerGroupCD;
	@Column(name="AGREEMENT_RQD", length=1, columnDefinition="char")
	private String agreementRequired;
//	@OneToOne(cascade=CascadeType.ALL)
//	@JoinColumn(name="id")
	//private TruckerGroup truckerGroup;
	@Column(name="CHECK_TKR", length=1, columnDefinition="char")
	private String checkTrucker;
	//@OneToMany(cascade=CascadeType.ALL)
	//@JoinColumn(name="terminalId")
	//private List<Terminal> terminals;
	//private List<PoolEquipmentRange> poolEquipmentRanges;
	//private List<PoolEquipmentController> poolEquipmentControllers
	//private List<PoolCustomer> poolCustomers;
	@Column(name="U_VERSION", length=1, columnDefinition="char")
	private String uVersion;
	@Column(name="CREATE_USER_ID", columnDefinition="char(8)")
	private String createUserId;
	@Column(name="UPD_USER_ID", columnDefinition="char(8)")
	private String updateUserId;
	
	@CreationTimestamp
	@Column(name="CREATE_DT_TM")
	private Timestamp createDTM;
	//private String createUser;
//	@Column(name="CREATE_EXTN_SCHEMA")
//	private String createExtensionSchema;
	
	@UpdateTimestamp
	@Column(name="UPD_DT_TM")
	private Timestamp updateDTM;
	//private String updateUser;
	@Column(name="UPD_EXTN_SCHEMA", columnDefinition="char(16)")
	private String updateExtentionSchema;
	public Double getPoolId() {
		return poolId;
	}
	
	public String getCreateUserId() {
		return createUserId;
	}
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}
	public String getUpdateUserId() {
		return updateUserId;
	}
	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
//	public PoolType getReservationType() {
//		return reservationType;
//	}
//	public void setReservationType(PoolType reservationType) {
//		this.reservationType = reservationType;
//	}
	public String getAgreementRequired() {
		return agreementRequired;
	}
	public void setAgreementRequired(String agreementRequired) {
		this.agreementRequired = agreementRequired;
	}
//	public TruckerGroup getTruckerGroup() {
//		return truckerGroup;
//	}
//	public void setTruckerGroup(TruckerGroup truckerGroup) {
//		this.truckerGroup = truckerGroup;
//	}
	public String getCheckTrucker() {
		return checkTrucker;
	}
	public void setCheckTrucker(String checkTrucker) {
		this.checkTrucker = checkTrucker;
	}
	public String getuVersion() {
		return uVersion;
	}
	public void setuVersion(String uVersion) {
		this.uVersion = uVersion;
	}
	public Timestamp getCreateDTM() {
		return createDTM;
	}
	public void setCreateDTM(Timestamp createDTM) {
		this.createDTM = createDTM;
	}
	
	public Timestamp getUpdateDTM() {
		return updateDTM;
	}
	public void setUpdateDTM(Timestamp updateDTM) {
		this.updateDTM = updateDTM;
	}
	
	public String getUpdateExtentionSchema() {
		return updateExtentionSchema;
	}
	public void setUpdateExtentionSchema(String updateExtentionSchema) {
		this.updateExtentionSchema = updateExtentionSchema;
	}
	
	public String getPoolName() {
		return poolName;
	}
	public void setPoolName(String poolName) {
		this.poolName = poolName;
	}
	public void setPoolId(Double poolId) {
		this.poolId = poolId;
	}
	public Pool() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
