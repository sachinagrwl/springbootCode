package com.nscorp.obis.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.nscorp.obis.domain.TermTrainComposite;
import com.nscorp.obis.domain.TerminalTrain;


public interface TerminalTrainRepository extends JpaRepository<TerminalTrain,TermTrainComposite>{
	
	/* boolean findByTermIdAndTrainNr(Long termId, String trainNr); */

	boolean existsByTermIdAndTrainNr(Long termId, String trainNr);

	TerminalTrain findByTermIdAndTrainNr(Long termId, String trainNr);
	
	void deleteByTermIdAndTrainNr(Long termId, String trainNr);

	
}