package com.nscorp.obis.common;

public class ControllerConstants {

	public static final String URI = "obis/business/services/intermodal";
	public static final String GENERIC_TABLE_LIST = URI + "/generictable";
	public static final String GET_GENERIC_CODE_TABLE = URI + "/genericcodelist/table/{tableName}";
	public static final String EQUIPMENT_TARE_WEIGHTS = URI + "/equipmenttareweights";
	public static final String POSITIONAL_WEIGHT_LIMITS = URI + "/positionalloadlimits";
	public static final String GET_SEC_RESOURCE = URI + "/resourcelist";
	public static final String ADD_GENERIC_TABLE = URI + "/generictablelist/add";

	public static final String STEAMSHIP_CUSTOMERS = URI + "/steamshipcustomers";
	public static final String ADD_STEAMSHIP_CUSTOMERS = URI + "/steamshipcustomers/add";
	public static final String GET_CORPORATE_CUSTOMERS = URI + "/corporatecustomers";

	public static final String DELETE_STEAMSHIP_CUSTOMERS = URI + "/steamshipcustomers/delete";

	public static final String TERMINAL_NOTIFY_PROFILES= URI + "/terminalNotifyProfile";
	public static final String UPDATE_TERMINAL_NOTIFY_PROFILES= URI + "/terminalNotifyProfile/update";
	public static final String GET_CUSTOMER_NOTIFY_PROFILES= URI + "/customerNotifyProfile";
	public static final String STATION_RESTRICTIONS = URI + "/station/{term-id}/station-restrictions";

	public static final String AAR_TYPE_LIST = URI + "/aar-types";

	public static final String NOTIFY_PROFILE_METHOD = URI + "/notify-profile-methods";
	public static final String CUSTOMER_NOTIFY_PROFILE =URI + "/customer-notify-profile";
	public static final String STATION = URI + "/stations";
	
	public static final String EMS_INGATE_RESTRICTION = URI + "/ems-ingate-restrictions";
	public static final String EMS_INGATE_ALLOCATION = URI + "/ems-ingate-allocation";

	public static final String STATION_CROSS = URI + "/stationxref";
	public static final String DESTINATION_TERMINAL_NOTIFY_PROFILE = URI + "/destination-terminal-notify-profiles";
	
	public static final String GET_TERMINAL_TRAINS = URI + "/terminal-trains";
	
	public static final String NOTIFICATION_TYPES = URI + "/notification_types";

	public static final String TERMINAL = URI + "/terminals";
	public static final String GET_BLOCKS = URI + "/blocks";
	public static final String UPDATE_TERM_TRAIN = URI + "/term-trains";
	public static final String DELETE_TERMINAL_TRAINS = URI + "/term-trains";
}
