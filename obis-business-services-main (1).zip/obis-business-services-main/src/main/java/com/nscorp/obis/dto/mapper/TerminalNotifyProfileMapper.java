package com.nscorp.obis.dto.mapper;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.nscorp.obis.domain.TerminalNotifyProfile;
import com.nscorp.obis.dto.TerminalNotifyProfileDTO;

@Mapper(componentModel = "spring")
public interface TerminalNotifyProfileMapper {
	TerminalNotifyProfileMapper INSTANCE = Mappers.getMapper(TerminalNotifyProfileMapper.class);

	TerminalNotifyProfileDTO terminalNotifyProfileToTerminalNotifyProfileDTO(TerminalNotifyProfile terminalNotifyProfiles);

	TerminalNotifyProfile terminalNotifyProfileDTOToTerminalNotifyProfile(TerminalNotifyProfileDTO terminalNotifyProfilesDTO);
	
}
