package com.nscorp.obis.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BlockComposite implements Serializable {
	private double blockId;
	
	public BlockComposite() {
		super();
	}
	public BlockComposite(double blockId) {
		this.setBlockId(blockId);
	}
	public double getBlockId() {
		return blockId;
	}
	public void setBlockId(double blockId) {
		this.blockId = blockId;
	}
}
