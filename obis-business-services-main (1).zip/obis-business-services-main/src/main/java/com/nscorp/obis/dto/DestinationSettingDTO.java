package com.nscorp.obis.dto;

import java.sql.Time;

import lombok.Data;
import lombok.EqualsAndHashCode;
@Data
@EqualsAndHashCode(callSuper = false)
public class DestinationSettingDTO {
	private Double destId; 
	private Double NsDestTermId;
	private Double offlineDest; 
	private Double TofcAllowedInd;
	private String cofcAllowedInd;
	private Integer onlineMileage; 
	private Integer offlineMileage;
	private Double blockId; 
	private String route;
	private String transitDays;
	private Time placeTm; 
	private String includeExclude;
}
