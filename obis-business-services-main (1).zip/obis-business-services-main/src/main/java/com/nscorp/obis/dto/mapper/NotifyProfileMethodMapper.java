package com.nscorp.obis.dto.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.nscorp.obis.domain.NotifyProfileMethod;
import com.nscorp.obis.dto.NotifyProfileMethodDTO;


@Mapper(componentModel = "spring")
public interface NotifyProfileMethodMapper {

	
	NotifyProfileMethodMapper INSTANCE = Mappers.getMapper(NotifyProfileMethodMapper.class);

	NotifyProfileMethodDTO notifyProfileMethodToNotifyProfileMethodDTO(NotifyProfileMethod notifyProfileMethods);

	NotifyProfileMethod notifyProfileMethodDTOToNotifyProfileMethod(NotifyProfileMethodDTO notifyProfileMethodsDTO);
	
}