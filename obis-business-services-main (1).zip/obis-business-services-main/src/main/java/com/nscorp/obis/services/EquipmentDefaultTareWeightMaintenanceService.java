package com.nscorp.obis.services;

import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import com.nscorp.obis.domain.EquipmentDefaultTareWeightMaintenance;

public interface EquipmentDefaultTareWeightMaintenanceService  {
	List<EquipmentDefaultTareWeightMaintenance> getAllTareWeights();
	EquipmentDefaultTareWeightMaintenance addTareWeight(@Valid EquipmentDefaultTareWeightMaintenance tareWeightObj, Map<String,String> headers);
	EquipmentDefaultTareWeightMaintenance updateWeight(@Valid EquipmentDefaultTareWeightMaintenance tareWeightObj, Map<String,String> headers);
	void deleteWeight(@Valid EquipmentDefaultTareWeightMaintenance tareWeightObj);
}
