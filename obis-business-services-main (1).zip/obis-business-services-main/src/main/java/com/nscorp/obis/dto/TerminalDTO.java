package com.nscorp.obis.dto;


import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

@Data
@EqualsAndHashCode(callSuper=false)
public class TerminalDTO {
	
	private Long terminalId;
	
	private String terminalName;

	private Long stnXrfId;
	
	private Date expiredDate;
}
