package com.nscorp.obis.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nscorp.obis.domain.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Double>{

	Customer findByCustomerId(Long customerId);

	boolean existsByCustomerId(Long customerId);

}
