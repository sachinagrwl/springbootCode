package com.nscorp.obis.services;

import java.util.List;

import com.nscorp.obis.dto.NotificationTypesResponseDTO;

public interface NotificationTypesService {

	List<NotificationTypesResponseDTO> fetchNotificationTypes();

}
