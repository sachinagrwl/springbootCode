package com.nscorp.obis.domain;

public enum WeightQualifier {

	GT, GE, LT, LE;
}
