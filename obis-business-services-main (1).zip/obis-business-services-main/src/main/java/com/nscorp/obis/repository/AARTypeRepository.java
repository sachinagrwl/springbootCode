package com.nscorp.obis.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nscorp.obis.domain.AARType;

@Repository
public interface AARTypeRepository extends JpaRepository <AARType, String> {

	List<AARType> findByAarTypeStartsWith(String c);

	boolean existsByAarType(String upperCase);
	

}
