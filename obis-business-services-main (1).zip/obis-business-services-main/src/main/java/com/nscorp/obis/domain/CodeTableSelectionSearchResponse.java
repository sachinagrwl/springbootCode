package com.nscorp.obis.domain;

public interface CodeTableSelectionSearchResponse {
	
	String getGenericTable();
	String getGenericTableDesc();
	short getGenCdFldSize();
	String getResourceNm();
}
