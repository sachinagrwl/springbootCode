package com.nscorp.obis.domain;

public enum EMSEquipmentLengthRestriction {

	RESTRICT_ALL,
	RESTRICT_20_FT,
	RESTRICT_40_FT,
	RESTRICT_45_FT,
	RESTRICT_53_FT
}
