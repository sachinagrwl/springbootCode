package com.nscorp.obis.domain;

public enum LineOfBusiness {
	DOMESTIC, INTERNATIONAL, PREMIUM
}
