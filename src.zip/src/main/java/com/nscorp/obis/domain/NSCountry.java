package com.nscorp.obis.domain;

public enum NSCountry {

    USA, CAN, MEX;
}